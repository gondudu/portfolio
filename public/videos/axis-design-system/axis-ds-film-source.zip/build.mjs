import { readFileSync, writeFileSync, mkdirSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const root = new URL('.', import.meta.url).pathname;
const read = (p) => readFileSync(join(root, p), 'utf8');

// [file, family, weight, style]
// Brand: Mont AS (licensed, user-supplied). Publications: free lookalikes of the
// families the token export names — the commercial originals stay out of this file.
const FACES = [
  ['MontAS-Regular.woff2', 'MontAS', 400, 'normal'],
  ['MontAS-RegularItalic.woff2', 'MontAS', 400, 'italic'],
  ['MontAS-Bold.woff2', 'MontAS', 700, 'normal'],
  ['MontAS-BoldItalic.woff2', 'MontAS', 700, 'italic'],
  ['MontAS-Heavy.woff2', 'MontAS', 800, 'normal'],
  ['MontAS-HeavyItalic.woff2', 'MontAS', 800, 'italic'],

  // Gotham → Montserrat
  ['montserrat-700-normal.woff2', 'Sub Gotham', 700, 'normal'],
  // Gotham Condensed → Barlow Semi Condensed
  ['barlow-semi-condensed-600-normal.woff2', 'Sub Gotham Condensed', 600, 'normal'],
  ['barlow-semi-condensed-700-normal.woff2', 'Sub Gotham Condensed', 700, 'normal'],
  // Gotham XNarrow and Antenna Extra Condensed → Sofia Sans Extra Condensed
  ['sofia-sans-extra-condensed-400-normal.woff2', 'Sub XNarrow', 400, 'normal'],
  ['sofia-sans-extra-condensed-600-normal.woff2', 'Sub XNarrow', 600, 'normal'],
  ['sofia-sans-extra-condensed-700-normal.woff2', 'Sub XNarrow', 700, 'normal'],
  ['sofia-sans-extra-condensed-800-normal.woff2', 'Sub XNarrow', 800, 'normal'],
  ['sofia-sans-extra-condensed-800-italic.woff2', 'Sub XNarrow', 800, 'italic'],
  // Mark Pro → Figtree
  ['figtree-400-normal.woff2', 'Sub Mark', 400, 'normal'],
  ['figtree-800-normal.woff2', 'Sub Mark', 800, 'normal'],
  // FreightText Pro → Newsreader
  ['newsreader-400-normal.woff2', 'Sub Freight', 400, 'normal'],
  // Lucida Grande → DejaVu Sans
  ['dejavu-sans-400-normal.woff2', 'Sub Lucida', 400, 'normal'],
  ['dejavu-sans-700-normal.woff2', 'Sub Lucida', 700, 'normal'],

  // Exact: these are free families the tokens name directly
  ['sofia-sans-condensed-700-normal.woff2', 'Sofia Sans Condensed', 700, 'normal'],
  ['sofia-sans-condensed-800-normal.woff2', 'Sofia Sans Condensed', 800, 'normal'],
  ['roboto-400-normal.woff2', 'Roboto', 400, 'normal'],
  ['roboto-700-normal.woff2', 'Roboto', 700, 'normal'],
  ['oswald-500-normal.woff2', 'Oswald', 500, 'normal'],
  ['oswald-700-normal.woff2', 'Oswald', 700, 'normal'],
  ['open-sans-400-normal.woff2', 'Open Sans', 400, 'normal'],
  ['open-sans-700-normal.woff2', 'Open Sans', 700, 'normal'],

  // Tool chrome — not Inter
  ['ibm-plex-sans-400-normal.woff2', 'Plex', 400, 'normal'],
  ['ibm-plex-sans-500-normal.woff2', 'Plex', 500, 'normal'],
  ['ibm-plex-sans-600-normal.woff2', 'Plex', 600, 'normal'],
  ['ibm-plex-mono-400-normal.woff2', 'Plex Mono', 400, 'normal'],
  ['ibm-plex-mono-500-normal.woff2', 'Plex Mono', 500, 'normal'],
  // Storybook's own UI face
  ['nunito-sans-400-normal.woff2', 'Nunito Sans', 400, 'normal'],
  ['nunito-sans-600-normal.woff2', 'Nunito Sans', 600, 'normal'],
  ['nunito-sans-700-normal.woff2', 'Nunito Sans', 700, 'normal'],
  ['nunito-sans-800-normal.woff2', 'Nunito Sans', 800, 'normal'],
];

const fontCss = FACES.map(([f, fam, w, s]) => {
  const b64 = readFileSync(join(root, 'fonts', f)).toString('base64');
  return `@font-face{font-family:"${fam}";font-weight:${w};font-style:${s};font-display:block;` +
    `src:url(data:font/woff2;base64,${b64}) format("woff2")}`;
}).join('\n');

// Logos come from @spring-media/axis-assets; the short form's white plate is dropped
// so it sits on any background.
const svg = (p) => read(p).replace(/<\?xml[^>]*>/, '').replace(/<!--[\s\S]*?-->/g, '').replace(/<!DOCTYPE[^>]*>/, '').trim();
const ASSETS = {
  logoOnDark: svg('logos/on-dark.svg'),
  logoPrimary: svg('logos/primary.svg'),
  logoShort: svg('logos/short.svg').replace(/<rect[^>]*fill="white"[^>]*\/>/, ''),
  emojiPalette: svg('logos/emoji-palette.svg'),
};

const FAMILIES = [...new Set(FACES.map(([, fam, w, s]) => `${s === 'italic' ? 'italic ' : ''}${w} 40px "${fam}"`))];

const css = read('src/film.css');
const core = read('src/core.js');
const kit = read('src/kit.js');
const ui = read('src/ui.js');
const acts = read('src/acts.js');
const glyphs = read('src/glyphs.js');
const intro = read('src/intro.js');
const films = readdirSync(join(root, 'src/films')).filter((f) => f.endsWith('.js'))
  .map((f) => read(join('src/films', f))).join('\n');

const page = `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Axis Design System</title>
<style>${fontCss}
${css}
.player{position:fixed;left:0;right:0;bottom:0;height:64px;background:#000;display:flex;align-items:center;gap:18px;padding:0 22px;color:#fff;font-family:"MontAS",sans-serif}
.pbtn{background:#fff;color:#000;border:0;width:44px;height:36px;font-size:15px;cursor:pointer;font-family:inherit}
.scrub{flex:1;height:6px;background:#2a2a2a;cursor:pointer}
.scrubfill{height:100%;background:#0000FF;width:0}
.ptime{font-size:16px;font-variant-numeric:tabular-nums;min-width:140px;text-align:right;color:#878787}
body.render-mode .player{display:none}
</style></head>
<body><div id="stage"></div>
<script>window.__axisFilm={ASSETS:${JSON.stringify(ASSETS)},FAMILIES:${JSON.stringify(FAMILIES)}};</script>
<script>(function(){${core}})();</script>
<script>(function(){${kit}})();</script>
<script>(function(){${ui}})();</script>
<script>(function(){${acts}})();</script>
<script>${glyphs}</script>
<script>(function(){${intro}})();</script>
<script>(function(){${films}})();</script>
<script>window.__axisFilm.boot();</script>
</body></html>`;

mkdirSync(join(root, 'dist'), { recursive: true });
writeFileSync(join(root, 'dist/axis-ds.html'), page);
console.log('built dist/axis-ds.html', (page.length / 1024).toFixed(0) + ' KB');
