import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';

const root = new URL('.', import.meta.url).pathname;
const [, , mode = 'video', film = 'axis-ds', ...rest] = process.argv;
const FPS = 60;

const open = async () => {
  const browser = await chromium.launch({ args: ['--font-render-hinting=none', '--disable-gpu'] });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  await page.goto('file://' + join(root, 'dist', film + '.html') + '#render-' + film);
  await page.waitForFunction('window.__ready === true', null, { timeout: 60000 });
  return { browser, page };
};

if (mode === 'stills') {
  const { browser, page } = await open();
  mkdirSync(join(root, 'stills'), { recursive: true });
  for (const t of rest.map(Number)) {
    await page.evaluate((x) => window.__axis.seek(x), t);
    await page.screenshot({ path: join(root, 'stills', `${film}-${t}.png`) });
    console.log('still', t);
  }
  await browser.close();
} else {
  const { browser, page } = await open();
  const dur = await page.evaluate(() => window.__axis.duration);
  const frames = Math.round(dur * FPS);
  mkdirSync(join(root, 'out'), { recursive: true });
  const outPath = join(root, 'out', film + '.mp4');
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(FPS),
    '-i', '-', '-c:v', 'libx264', '-preset', 'slow', '-crf', '15', '-pix_fmt', 'yuv420p',
    '-tune', 'animation', '-movflags', '+faststart', outPath]);
  ff.stderr.on('data', (d) => process.stderr.write(d));
  console.log('rendering', frames, 'frames →', outPath);
  for (let f = 0; f < frames; f++) {
    await page.evaluate((x) => window.__axis.seek(x), f / FPS);
    const buf = await page.screenshot({ type: 'jpeg', quality: 96 });
    if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
    if (f % 300 === 0) console.log('  frame', f, '/', frames);
  }
  ff.stdin.end();
  await new Promise((r) => ff.on('close', r));
  await browser.close();
  console.log('done', outPath);
}
