// ─────────────────────────────────────────────────────────────────────────────
// ui.js — faithful tool surfaces. Every name, value and label here comes from
// the axis-design-system repository (token export, workflows, READMEs).
// ─────────────────────────────────────────────────────────────────────────────
const A = window.__axisFilm;
const { h, S, E, prog } = A;
const U = (A.ui = {});

// ── icons (24px grid, 1.6 stroke) ──────────────────────────────────────────
const P = {
  x: 'M6 6l12 12M18 6L6 18',
  chev: 'M6 9l6 6 6-6',
  chevR: 'M9 6l6 6-6 6',
  frame: 'M8 3v18M16 3v18M3 8h18M3 16h18',
  search: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4',
  zoomIn: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4M8 11h6M11 8v6',
  zoomOut: 'M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4M8 11h6',
  reset: 'M4 12a8 8 0 1 0 2.3-5.7M4 4v4h4',
  image: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M15 9.5a1 1 0 1 0 .01 0',
  grid: 'M4 4h16v16H4zM4 10h16M4 16h16M10 4v16M16 4v16',
  outline: 'M5 5h14v14H5zM9 9h6v6H9z',
  ruler: 'M3 17L17 3l4 4L7 21zM7 13l2 2M10 10l2 2M13 7l2 2',
  brush: 'M14 4l6 6-8 8-6-6zM6 12l-2 6 6-2',
  doc: 'M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6',
  comp: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  sun: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.4 1.4M17.6 17.6L19 19M5 19l1.4-1.4M17.6 6.4L19 5',
  full: 'M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5',
  share: 'M14 4h6v6M20 4l-9 9M18 14v6H4V6h6',
  check: 'M5 12.5l4.5 4.5L19 7.5',
  pr: 'M6 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM6 7v10M6 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM18 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM18 17V9a3 3 0 0 0-3-3h-4M13 3l-2 3 2 3',
  merge: 'M6 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM6 7v14M18 13a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM18 13c0-4-6-4-12-6',
  file: 'M7 3h7l5 5v13H7zM14 3v5h5',
  play: 'M7 5l12 7-12 7z',
  files: 'M8 3h7l4 4v11H8zM5 7v14h11',
  git: 'M6 3a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM6 7v10M6 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM18 7a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM18 11c0 4-6 3-12 6',
  ext: 'M4 4h7v7H4zM13 13h7v7h-7zM4 13h7v7H4zM15 3l5 5-5 5-5-5z',
  warn: 'M12 3l10 18H2zM12 10v5M12 18v.5',
  folder: 'M3 6h6l2 2h10v11H3z',
  dots: 'M5 12h.01M12 12h.01M19 12h.01',
};
U.icon = (name, size = 20, color = 'currentColor', sw = 1.6) =>
  h('span', { class: 'ic', html: `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round"><path d="${P[name]}"/></svg>` });

// ── window ──────────────────────────────────────────────────────────────────
U.win = ({ x, y, w, hgt, dark = false, title = '', bar = true }) => {
  const tb = bar ? h('div', { class: 'tb' }, h('span', { class: 'tl r' }), h('span', { class: 'tl y' }), h('span', { class: 'tl g' }),
    h('div', { class: 'tt', text: title })) : null;
  const body = h('div', { style: `position:absolute;left:0;right:0;top:${bar ? 46 : 0}px;bottom:0;overflow:hidden` });
  const el = h('div', { class: 'win' + (dark ? ' dark' : ''), style: `left:${x}px;top:${y}px;width:${w}px;height:${hgt}px` }, tb, body);
  return { el, body, tb };
};

// Browser chrome (light) — tab strip + address bar.
U.browser = ({ x, y, w, hgt, tab, url }) => {
  const W = U.win({ x, y, w, hgt, bar: false });
  const tabEl = h('div', { style: 'position:absolute;left:96px;bottom:0;height:34px;padding:0 18px;background:#fff;border-radius:10px 10px 0 0;display:flex;align-items:center;gap:10px;font-size:15px;color:#3C4043;min-width:220px' },
    h('span', { style: 'width:14px;height:14px;border-radius:3px;background:#0000FF;display:inline-block' }), h('span', { class: 'tabt', text: tab }));
  const strip = h('div', { style: 'position:relative;height:44px;background:#DEE1E6;display:flex;align-items:center;gap:9px;padding:0 18px' },
    h('span', { class: 'tl r' }), h('span', { class: 'tl y' }), h('span', { class: 'tl g' }), tabEl);
  const urlEl = h('span', { class: 'url', text: url });
  const addr = h('div', { style: 'height:48px;background:#fff;display:flex;align-items:center;gap:14px;padding:0 16px;border-bottom:1px solid #E3E3E3' },
    h('span', { style: 'color:#5F6368;font-size:20px', text: '‹  ›' }),
    h('div', { style: 'flex:1;height:32px;border-radius:16px;background:#EFF1F3;display:flex;align-items:center;padding:0 16px;font-size:16px;color:#202124;gap:8px' },
      h('span', { style: 'color:#5F6368', text: '⌂' }), urlEl));
  const content = h('div', { style: 'position:absolute;left:0;right:0;top:92px;bottom:0;overflow:hidden' });
  W.body.style.top = '0';
  W.body.append(strip, addr, content);
  return { el: W.el, content, setUrl: (u) => { if (urlEl.textContent !== u) urlEl.textContent = u; }, setTab: (t) => { const n = tabEl.querySelector('.tabt'); if (n.textContent !== t) n.textContent = t; } };
};

// ── Figma: Local variables dialog ───────────────────────────────────────────
// Collections in export order with their real variable counts.
const COLLECTIONS = [['_FontPrimitive', 108], ['_ColorPrimitive', 409], ['Mode', 314], ['_SpacePrimitive', 23], ['_SizePrimitive', 46],
  ['Density', 45], ['Breakpoint', 638], ['BrandType', 368], ['BrandTheme', 156], ['Platform', 16]];

U.figmaVariables = ({ x, y, w, hgt, nameCol = 330, modeCol = 196 }) => {
  const list = h('div', { style: 'width:236px;flex:none;border-right:1px solid #EBEBEB;padding:14px 10px' },
    h('div', { style: 'font-size:14px;color:#8C8C8C;padding:4px 10px 10px', text: 'Collections' }));
  const items = {};
  for (const [n, c] of COLLECTIONS) {
    const it = h('div', { 'data-a': 'col-' + n, style: 'display:flex;justify-content:space-between;align-items:center;height:38px;padding:0 10px;border-radius:6px;font-size:16px;color:#1E1E1E' },
      h('span', { text: n }), h('span', { style: 'color:#9A9A9A;font-size:14px', text: String(c) }));
    items[n] = it; list.appendChild(it);
  }
  const table = h('div', { style: 'flex:1;overflow:hidden;position:relative' });
  const head = h('div', { style: 'display:flex;align-items:center;justify-content:space-between;height:56px;padding:0 20px;border-bottom:1px solid #EBEBEB' },
    h('div', { style: 'font-size:18px;font-weight:600', text: 'Local variables' }),
    h('div', { 'data-a': 'fv-close', style: 'color:#6B6B6B;display:flex' }, U.icon('x', 20)));
  const el = h('div', { style: `position:absolute;left:${x}px;top:${y}px;width:${w}px;height:${hgt}px;background:#fff;border-radius:13px;overflow:hidden;font-family:var(--plex);color:#1E1E1E;box-shadow:0 0 0 1px rgba(0,0,0,.12),0 18px 48px rgba(0,0,0,.22)` },
    head, h('div', { style: `display:flex;height:${hgt - 56}px` }, list, table));

  const views = {};
  // spec: {modes:[...], groups:[{path, rows:[{name, swatch, cells:[{alias?, val?, sw}]}]}]}
  function build(key, spec) {
    const v = h('div', { style: 'position:absolute;inset:0;padding:0 0 0 0' });
    const hdr = h('div', { style: 'display:flex;height:44px;align-items:center;border-bottom:1px solid #EBEBEB;font-size:14px;color:#8C8C8C' },
      h('div', { style: `width:${nameCol}px;padding-left:22px;flex:none`, text: 'Name' }),
      ...spec.modes.map((m) => h('div', { style: `width:${modeCol}px;flex:none;padding-left:12px`, text: m })));
    v.appendChild(hdr);
    const rowEls = {};
    for (const g of spec.groups) {
      v.appendChild(h('div', { style: 'height:40px;display:flex;align-items:center;padding-left:22px;font-size:14px;color:#8C8C8C;font-weight:500', text: g.path }));
      for (const r of g.rows) {
        const cells = r.cells.map((c, i) => {
          const inner = c.alias
            ? h('span', { class: 'pill' }, h('span', { class: 'sw', style: `background:${c.sw}` }), h('span', { text: c.alias }))
            : h('span', { style: 'display:inline-flex;align-items:center;gap:9px;font-size:16px' }, h('span', { class: 'sw', style: `background:${c.sw}` }), h('span', { class: 'mono val', style: 'font-size:15px', text: c.val }));
          return h('div', { 'data-a': `${key}-${r.name}-${i}`, style: `width:${modeCol}px;flex:none;padding-left:12px;overflow:hidden` }, inner);
        });
        const row = h('div', { 'data-a': `${key}-${r.name}`, style: 'display:flex;align-items:center;height:50px;border-bottom:1px solid #F4F4F4' },
          h('div', { style: `width:${nameCol}px;flex:none;padding-left:22px;display:flex;align-items:center;gap:11px;font-size:16px` },
            h('span', { class: 'sw', style: `width:18px;height:18px;background:${r.swatch}` }), h('span', { text: r.name })),
          ...cells);
        rowEls[r.name] = row; v.appendChild(row);
      }
    }
    views[key] = { el: v, rows: rowEls };
    table.appendChild(v);
  }
  return {
    el, items, views, build,
    show(key) {
      for (const k in views) S(views[k].el, { visibility: k === key ? 'visible' : 'hidden' });
      for (const n in items) S(items[n], { background: n === key ? '#EBEBEB' : 'transparent', fontWeight: n === key ? '600' : '400' });
    },
    highlight(key, name, on) {
      const r = views[key] && views[key].rows[name];
      if (r) S(r, { background: on ? '#E7F1FF' : 'transparent' });
    },
  };
};

// ── code editor (VS Code, Dark Modern palette) ──────────────────────────────
const SYN = { t: '#569CD6', a: '#9CDCFE', v: '#CE9178', p: '#808080', x: '#CCCCCC', s: '#D7BA7D', k: '#9CDCFE', f: '#DCDCAA', c: '#6A9955', n: '#B5CEA8' };
// line = [[cls, text], ...]
U.codeLines = (lines, { size = 21, lh = 34, gutter = 58 } = {}) => {
  const box = h('div', { style: `position:relative;font-family:var(--mono);font-size:${size}px;line-height:${lh}px;padding-top:10px` });
  const els = lines.map((ln, i) => {
    const code = h('div', { style: 'white-space:pre;position:relative' });
    for (const [c, t] of ln) code.appendChild(h('span', { class: 'tok-' + c, style: `color:${SYN[c] || SYN.x}`, text: t }));
    const row = h('div', { 'data-a': 'ln' + (i + 1), style: `display:flex;height:${lh}px` },
      h('div', { style: `width:${gutter}px;flex:none;text-align:right;padding-right:20px;color:#6E7681`, text: String(i + 1) }), code);
    box.appendChild(row);
    return { row, code };
  });
  return { el: box, lines: els };
};

// A replaceable value inside a code line (attribute value, css value …).
U.editable = (span) => {
  const st = { cur: span.textContent };
  return {
    span,
    // selection highlight + typed replacement, all as a function of t
    run(t, from, to, tSel, tType, cps = 18) {
      const sel = t >= tSel && t < tType;
      let txt = from;
      if (t >= tType) {
        const n = Math.max(0, Math.round((t - tType) * cps));
        txt = to.slice(0, n);
      }
      const q = (s) => '"' + s + '"';
      const shown = t >= tType ? q(txt) : q(from);
      if (st.cur !== shown) { st.cur = shown; span.textContent = shown; }
      S(span, { background: sel ? '#264F78' : 'transparent', outline: 'none' });
      return t >= tType && txt.length === to.length;
    },
  };
};

// ── the publication teaser (renders a real attribute state) ─────────────────
// Colours: resolved from the token export per colour brand and mode.
const COL = {
  'bild/light': { bg: '#FFFFFF', bg2: '#F2F4F5', text: '#222628', sec: '#565A5F', brand: '#DD0000', btn: '#DD0000', border: '#C4C9CF' },
  'bild/dark': { bg: '#222628', bg2: '#2C3133', text: '#DDE1E2', sec: '#A6ABB0', brand: '#F75849', btn: '#DD0000', border: '#565A5F' },
  'sportbild/light': { bg: '#FFFFFF', bg2: '#EFF1F5', text: '#222628', sec: '#565A5F', brand: '#0C2F61', btn: '#174482', border: '#C3C9DB' },
  'sportbild/dark': { bg: '#0B2647', bg2: '#0C2F61', text: '#D6E1F2', sec: '#8FACDB', brand: '#6A91CF', btn: '#174482', border: '#345EA0' },
};
// Type: the content brand's families (BrandType), in free lookalikes.
const TYPE = {
  bild: {
    kicker: 'font-family:"Sub XNarrow";font-weight:700;letter-spacing:.02em;text-transform:uppercase;',
    head: 'font-family:"Sub Gotham Condensed";font-weight:700;letter-spacing:-.005em;line-height:1.04;',
    body: 'font-family:"Sub XNarrow";font-weight:400;line-height:1.32;',
    meta: 'font-family:"Sub XNarrow";font-weight:600;',
    btn: 'font-family:"Sub XNarrow";font-weight:700;', r: 8, ks: 24, hs: 60, bs: 27,
  },
  advertorial: {
    kicker: 'font-family:"Sub Lucida";font-weight:700;letter-spacing:.08em;text-transform:uppercase;',
    head: 'font-family:"Sub Lucida";font-weight:700;letter-spacing:-.01em;line-height:1.16;',
    body: 'font-family:"Sub Lucida";font-weight:400;line-height:1.5;',
    meta: 'font-family:"Sub Lucida";font-weight:400;',
    btn: 'font-family:"Sub Lucida";font-weight:700;', r: 8, ks: 17, hs: 44, bs: 21,
  },
};
U.teaser = () => {
  const nav = h('div', { style: 'display:flex;gap:30px;align-items:center;height:64px;padding:0 48px;border-bottom:1px solid' },
    ...['Politik', 'Sport', 'Regional', 'Geld', 'Ratgeber'].map((t) => h('span', { class: 'nv', text: t })));
  const rule = h('div', { style: 'height:6px' });
  const kicker = h('div', { text: 'Exklusiv' });
  const head = h('div', { text: 'Die Stadt baut 4.000 neue Wohnungen' });
  const body = h('div', { text: 'Der Senat hat den Plan am Dienstag beschlossen. Die ersten Bauarbeiten beginnen im Frühjahr.' });
  const meta = h('div', { text: 'vor 12 Min. · Berlin' });
  const btn = h('div', { 'data-a': 'teaser-btn', style: 'display:inline-flex;align-items:center;color:#fff', text: 'Weiterlesen' });
  const card = h('div', { style: 'display:flex;flex-direction:column' }, kicker, head, body, meta, h('div', null, btn));
  const more = h('div', { style: 'border-top:1px solid;display:flex;flex-direction:column' },
    h('div', { class: 'k2', text: 'Verkehr' }), h('div', { class: 'h2', text: 'Neue Tram-Linie fährt ab Juni durch Pankow' }));
  const page = h('div', { style: 'position:absolute;inset:0;overflow:hidden' }, rule, nav, h('div', { class: 'wrap', style: 'padding:0 48px' }, card, more));
  return {
    el: page,
    apply({ color, content, density, theme }) {
      const c = COL[`${color}/${theme}`]; const ty = TYPE[content]; const dense = density === 'dense';
      const k = dense ? 0.64 : 1;
      S(page, { background: c.bg });
      S(rule, { background: c.btn });
      S(nav, { borderColor: c.border, color: c.text });
      nav.querySelectorAll('.nv').forEach((n) => n.setAttribute('style', ty.meta + `font-size:${dense ? 19 : 21}px;color:${c.text}`));
      S(card, { gap: Math.round(18 * k) + 'px', paddingTop: Math.round(46 * k) + 'px', paddingBottom: Math.round(40 * k) + 'px' });
      kicker.setAttribute('style', ty.kicker + `font-size:${ty.ks}px;color:${c.brand}`);
      head.setAttribute('style', ty.head + `font-size:${ty.hs}px;color:${c.text}`);
      body.setAttribute('style', ty.body + `font-size:${ty.bs}px;color:${c.sec}`);
      meta.setAttribute('style', ty.meta + `font-size:${Math.round(ty.bs * 0.72)}px;color:${c.sec}`);
      const bfs = dense ? 20 : 23;
      btn.setAttribute('style', ty.btn + `display:inline-flex;align-items:center;color:#fff;background:${c.btn};font-size:${bfs}px;` +
        `border-radius:${Math.round(ty.r * 1.35)}px;padding:0 ${dense ? 22 : 30}px;height:${dense ? 48 : 62}px;margin-top:${Math.round(8 * k)}px`);
      S(more, { borderColor: c.border, gap: Math.round(10 * k) + 'px', paddingTop: Math.round(28 * k) + 'px' });
      more.querySelector('.k2').setAttribute('style', ty.kicker + `font-size:${Math.round(ty.ks * 0.85)}px;color:${c.brand}`);
      more.querySelector('.h2').setAttribute('style', ty.head + `font-size:${Math.round(ty.hs * 0.62)}px;color:${c.text}`);
    },
  };
};

// ds-button as each brand renders it (BrandTheme colour + BrandType label)
U.dsButton = (b, scale = 2, label = 'Jetzt lesen') => {
  const bt = b.button;
  const fs = bt.size * scale;
  return h('div', {
    style: A.font(bt) + `display:inline-flex;align-items:center;justify-content:center;background:${b.c};color:#fff;` +
      `font-size:${fs}px;height:${Math.round((bt.size >= 17 ? 48 : 40) * scale)}px;padding:0 ${Math.round(20 * scale)}px;border-radius:${bt.r * scale}px;white-space:nowrap`,
  }, label);
};
