// ─────────────────────────────────────────────────────────────────────────────
// Axis Design System — overview film (running order)
// ─────────────────────────────────────────────────────────────────────────────
const A = window.__axisFilm;

A.films['axis-ds'] = Object.assign(function (stage) {
  const segs = [];
  let t = 0;
  const put = (dur, obj, punch = true) => {
    stage.appendChild(obj.el);
    const a = t;
    segs.push({ a, b: a + dur, el: obj.el, punch, render: (lt) => obj.render(lt, dur) });
    t += dur;
  };
  const act = (num, label, sub, demoDur, builder) => {
    put(1.4, A.Flash(num, label, sub));
    const ws = A.Workspace({ who: 'User' });
    stage.appendChild(ws.el);
    const a = t;
    let render = null;
    segs.push({ a, b: a + demoDur, el: ws.el, punch: true, render: (lt) => { if (!render) { render = builder(ws); ws.measure(); } render(lt); } });
    t += demoDur;
  };

  put(12.1, A.Intro('A design system for every Axel Springer publication.'), false);
  put(4.2, A.Statement('the problem', ['Ten publications.', { em: 'Ten ways to build products.' }]));
  put(4.2, A.Statement('the problem', ['Ten teams', { em: 'No shared efforts.' }], { boldFooter: true }));
  put(3.8, A.Statement('the solution', ['A flexible system', { em: 'with brand sensibility.' }]));
  put(6.4, A.BrandWall());

  act('01', 'tokens', 'Four layers, one source.', 13, A.acts.tokens);
  act('02', 'theming', 'Two brand axes, density and theme.', 15, A.acts.theming);
  act('03', 'styleguide', 'Storybook, driven by the same tokens.', 13, A.acts.styleguide);
  act('04', 'pipeline', 'From Figma to npm, Maven and Swift.', 16, A.acts.pipeline);
  act('05', 'guardrails', 'Lint, CLI and a migration ledger.', 10, A.acts.guardrails);

  put(5.4, A.Results([
    ['10x', 'feature development <b>speed.</b>'],
    ['10', 'publications on one system — <b>three more onboarding</b>'],
    ['4', 'platforms from one source: <b>web, iOS, Android, Compose</b>'],
    ['0', 'manual export steps between <b>Figma and production</b>'],
  ]));
  put(4.8, A.Outro());

  return { duration: t, segs };
}, { label: 'Axis Design System' });
