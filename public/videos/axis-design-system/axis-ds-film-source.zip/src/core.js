// ─────────────────────────────────────────────────────────────────────────────
// core.js — deterministic animation engine
// Every frame is a pure function of time t. Nothing animates by itself.
// ─────────────────────────────────────────────────────────────────────────────

const A = (window.__axisFilm = window.__axisFilm || {});
A.films = {};

const clamp = (x, a = 0, b = 1) => (x < a ? a : x > b ? b : x);
const prog = (t, a, b) => (b === a ? (t >= b ? 1 : 0) : clamp((t - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;

const E = {
  lin: (p) => p,
  in3: (p) => p ** 3,
  out3: (p) => 1 - (1 - p) ** 3,
  out5: (p) => 1 - (1 - p) ** 5,
  io3: (p) => (p < 0.5 ? 4 * p ** 3 : 1 - (-2 * p + 2) ** 3 / 2),
  io5: (p) => (p < 0.5 ? 16 * p ** 5 : 1 - (-2 * p + 2) ** 5 / 2),
  outX: (p) => (p >= 1 ? 1 : 1 - 2 ** (-10 * p)),
  inX: (p) => (p <= 0 ? 0 : 2 ** (10 * p - 10)),
  ioX: (p) =>
    p <= 0 ? 0 : p >= 1 ? 1 : p < 0.5 ? 2 ** (20 * p - 10) / 2 : (2 - 2 ** (-20 * p + 10)) / 2,
  back: (p) => {
    const c1 = 1.7,
      c3 = c1 + 1;
    return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2;
  },
};

// 0 before a, rises over inD, holds, falls over outD ending at b
const win = (t, a, b, inD = 0.25, outD = 0.2, e = 'outX') =>
  Math.min(E[e](prog(t, a, a + inD)), 1 - E.out3(prog(t, b - outD, b)));

// keyframes [[time, value|array, easeArrivingHere], ...] → t => value
function track(keys) {
  return (t) => {
    if (t <= keys[0][0]) return keys[0][1];
    for (let i = 0; i < keys.length - 1; i++) {
      const k0 = keys[i],
        k1 = keys[i + 1];
      if (t < k1[0]) {
        const p = E[k1[2] || 'io3'](prog(t, k0[0], k1[0]));
        return Array.isArray(k0[1]) ? k0[1].map((v, j) => lerp(v, k1[1][j], p)) : lerp(k0[1], k1[1], p);
      }
    }
    return keys[keys.length - 1][1];
  };
}

// step list [[time, value], ...] → t => value (no interpolation)
function step(keys) {
  return (t) => {
    let v = keys[0][1];
    for (const [kt, kv] of keys) if (t >= kt) v = kv;
    return v;
  };
}

// tiny DOM builder
function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props)
    for (const k in props) {
      const v = props[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style') el.setAttribute('style', v);
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v;
      else el.setAttribute(k, v);
    }
  for (const kid of kids.flat(9)) {
    if (kid == null || kid === false) continue;
    el.appendChild(typeof kid === 'string' ? document.createTextNode(kid) : kid);
  }
  return el;
}

// write only changed styles
function S(el, o) {
  const c = el.__s || (el.__s = {});
  for (const k in o)
    if (c[k] !== o[k]) {
      c[k] = o[k];
      el.style[k] = o[k];
    }
}

const typed = (strval, t, t0, cps = 26) =>
  strval.slice(0, Math.max(0, Math.round((t - t0) * cps)));

Object.assign(A, { clamp, prog, lerp, E, win, track, step, h, S, typed });

// ─────────────────────────────────────────────────────────────────────────────
// Film runner
// ─────────────────────────────────────────────────────────────────────────────

const FONTS = A.FAMILIES || ['400 100px "MontAS"', '700 100px "MontAS"', '800 100px "MontAS"'];

A.boot = async function boot() {
  const hash = location.hash || '';
  const renderMatch = hash.match(/^#render-(.+)$/);
  const id = renderMatch ? renderMatch[1] : Object.keys(A.films)[0];
  const stage = document.getElementById('stage');

  const film = A.films[id](stage);
  const duration = film.duration;

  function draw(t) {
    for (const seg of film.segs) {
      const vis = t >= seg.a && t < seg.b;
      S(seg.el, { visibility: vis ? 'visible' : 'hidden' });
      if (!vis) continue;
      const lt = t - seg.a;
      seg.render(lt, t);
      if (seg.punch !== false && seg.a > 0) {
        const k = 1 + 0.035 * (1 - E.outX(prog(lt, 0, 0.55)));
        S(seg.el, { transform: `scale(${k.toFixed(5)})` });
      }
    }
  }

  try {
    await Promise.all(FONTS.map((f) => document.fonts.load(f, 'AaÜüß→_0123456789#')));
    await document.fonts.ready;
  } catch (e) {}

  if (renderMatch) {
    document.body.classList.add('render-mode');
    draw(0);
    window.__axis = { ids: [id], duration, seek: (t) => draw(t) };
    window.__ready = true;
    return;
  }

  // player chrome
  const bar = h('div', { class: 'player' },
    h('button', { class: 'pbtn', id: 'pp', text: '❚❚' }),
    h('div', { class: 'scrub', id: 'scrub' }, h('div', { class: 'scrubfill', id: 'sf' })),
    h('div', { class: 'ptime', id: 'ptime', text: '0.0 / ' + duration.toFixed(1) })
  );
  document.body.appendChild(bar);

  let t = 0,
    playing = true,
    last = performance.now();
  const pp = bar.querySelector('#pp'),
    sf = bar.querySelector('#sf'),
    pt = bar.querySelector('#ptime'),
    scrub = bar.querySelector('#scrub');
  pp.onclick = () => {
    playing = !playing;
    pp.textContent = playing ? '❚❚' : '▶';
  };
  const seekAt = (ev) => {
    const r = scrub.getBoundingClientRect();
    t = clamp((ev.clientX - r.left) / r.width) * duration;
    draw(t);
  };
  scrub.onmousedown = (e) => {
    seekAt(e);
    const mv = (e2) => seekAt(e2);
    const up = () => {
      window.removeEventListener('mousemove', mv);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', mv);
    window.addEventListener('mouseup', up);
  };
  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
      e.preventDefault();
      pp.click();
    }
    if (e.code === 'ArrowRight') { t = clamp(t + 1 / 60, 0, duration); draw(t); }
    if (e.code === 'ArrowLeft') { t = clamp(t - 1 / 60, 0, duration); draw(t); }
  });

  function fit() {
    const s = Math.min(window.innerWidth / 1920, (window.innerHeight - 64) / 1080);
    stage.style.transform = `scale(${s})`;
  }
  window.addEventListener('resize', fit);
  fit();

  function loop(now) {
    const dt = (now - last) / 1000;
    last = now;
    if (playing) {
      t += dt;
      if (t > duration) t = 0;
    }
    draw(t);
    sf.style.width = ((t / duration) * 100).toFixed(2) + '%';
    pt.textContent = t.toFixed(1) + ' / ' + duration.toFixed(1);
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  window.__axis = { ids: [id], duration, seek: (x) => draw(x) };
  window.__ready = true;
};
