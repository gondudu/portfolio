// ─────────────────────────────────────────────────────────────────────────────
// intro.js — the editorial opener. Type, shape and colour close up, then the
// wordmark: "axis" arrives, "design system" types in behind it, and the frame
// settles into the title card.
//
//   A 0.0  macro on the Mont AS Heavy "a" — real outline, real points
//   B 2.4  SportBILD italic "S" — upright → italic, the angle measured
//   C 4.0  brand colours as bars; BILD opens to its token
//   D 5.6  specimen grid — every brand's "Aa", flipping to its colour
//   E 7.2  macro on the "x", pull back to "axis"
//   F 8.8  "design system" arrives → title card
// ─────────────────────────────────────────────────────────────────────────────
const A = window.__axisFilm;
const { h, S, E, prog, lerp, track } = A;

const INK = '#0F0F0F', BLUE = '#0000FF', GREEN = '#00FF00', WHITE = '#FFFFFF';
const NS = 'http://www.w3.org/2000/svg';
const sv = (tag, attrs) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); return e; };
const rise = (el, t, t0, dur = 0.6, dy = 24) => {
  const p = E.out5(prog(t, t0, t0 + dur));
  S(el, { opacity: p.toFixed(3), transform: `translateY(${((1 - p) * dy).toFixed(1)}px)` });
};

// ── cursor (same proportions as the film's workspace pointer) ────────────────
const ARROW = '<svg width="120" height="120" viewBox="0 0 24 24" fill="none" style="position:absolute;left:0;top:0;filter:drop-shadow(0 6px 14px rgba(0,0,0,.35))"><path d="M5.5 2.8 19 12.4l-6.2.6-3.1 6.6z" fill="#fff" stroke="#111" stroke-width="1.5" stroke-linejoin="round"/></svg>';
function pointer(label, bg, fg) {
  const el = h('div', { style: 'position:absolute;left:0;top:0;width:0;height:0;z-index:30;will-change:transform' },
    h('div', { html: ARROW }),
    h('div', { style: `position:absolute;left:76px;top:104px;background:${bg};color:${fg};font-family:"MontAS";font-weight:800;font-style:italic;font-size:50px;line-height:1.2;padding:14px 32px 16px;border-radius:20px;white-space:nowrap`, text: label }));
  return {
    el,
    at(x, y, press = 0, o = 1) { S(el, { opacity: String(o), transform: `translate(${x.toFixed(1)}px,${y.toFixed(1)}px) scale(${(1 - press * 0.1).toFixed(3)})` }); },
  };
}
const press = (t, ct) => (t >= ct && t < ct + 0.22 ? Math.sin(((t - ct) / 0.22) * Math.PI) : 0);

// ── glyph outline in frame coordinates ───────────────────────────────────────
// map: X = ox + x*s, Y = oy - y*s (font units are y-up)
function glyph(g, { s, ox, oy, fill = WHITE, stroke = WHITE, sw = 3, handle = WHITE, anchorFill = INK }) {
  const P = (p) => [ox + p[0] * s, oy - p[1] * s];
  const svg = sv('svg', { width: 1920, height: 1080, viewBox: '0 0 1920 1080', style: 'position:absolute;left:0;top:0;overflow:visible' });
  const fillPath = sv('path', { fill, 'fill-rule': 'nonzero' });
  const outline = sv('path', { fill: 'none', stroke, 'stroke-width': sw, 'stroke-linejoin': 'round', pathLength: 1, 'stroke-dasharray': '1 1', 'stroke-dashoffset': 1 });
  const handles = sv('g', {}), marks = sv('g', {});
  svg.append(fillPath, handles, outline, marks);
  const pts = []; // editable copy of every point, so a control can be dragged
  const items = []; // reveal order: {nodes, i}
  let cur = null, start = null;
  const cmds = g.cmds.map(([op, ps]) => [op, ps.map((p) => { const q = { u: p.slice() }; pts.push(q); return q; })]);
  const build = () => {
    let d = '';
    cur = null; start = null;
    for (const [op, ps] of cmds) {
      const xy = ps.map((q) => P(q.u));
      if (op === 'moveTo') { d += `M${xy[0]}`; cur = xy[0]; start = xy[0]; }
      else if (op === 'lineTo') { d += `L${xy[0]}`; cur = xy[0]; }
      else if (op === 'curveTo') { d += `C${xy[0]} ${xy[1]} ${xy[2]}`; cur = xy[2]; }
      else if (op === 'qCurveTo') {
        for (let i = 0; i < xy.length - 1; i++) {
          const last = i === xy.length - 2;
          const end = last ? xy[i + 1] : [(xy[i][0] + xy[i + 1][0]) / 2, (xy[i][1] + xy[i + 1][1]) / 2];
          d += `Q${xy[i]} ${end}`;
        }
        cur = xy[xy.length - 1];
      } else if (op === 'closePath' || op === 'endPath') { d += 'Z'; cur = start; }
    }
    fillPath.setAttribute('d', d); outline.setAttribute('d', d);
  };
  build();
  // handles and point marks (positions refreshed by sync())
  const links = []; // [line, qa, qb]
  const marksArr = []; // [node, q, kind]
  {
    let prev = null, first = null;
    for (const [op, ps] of cmds) {
      if (op === 'moveTo') { prev = ps[0]; first = ps[0]; }
      const nodes = [];
      const link = (a, b) => { const l = sv('line', { stroke: handle, 'stroke-width': 1.6, opacity: 0.9 }); handles.appendChild(l); links.push([l, a, b]); nodes.push(l); };
      const mark = (q, kind) => {
        const m = kind === 'on' ? sv('rect', { width: 16, height: 16, fill: anchorFill, stroke: handle, 'stroke-width': 2.5 })
          : sv('circle', { r: 7, fill: handle });
        marks.appendChild(m); marksArr.push([m, q, kind]); nodes.push(m);
      };
      if (op === 'moveTo' || op === 'lineTo') mark(ps[0], 'on');
      if (op === 'curveTo') { link(prev, ps[0]); link(ps[1], ps[2]); mark(ps[0], 'off'); mark(ps[1], 'off'); mark(ps[2], 'on'); }
      if (op === 'qCurveTo') { let a = prev; for (const q of ps) { link(a, q); a = q; } ps.slice(0, -1).forEach((q) => mark(q, 'off')); mark(ps[ps.length - 1], 'on'); }
      if (ps.length) prev = ps[ps.length - 1];
      if (op === 'closePath') prev = first;
      if (nodes.length) items.push(nodes);
    }
  }
  const sync = () => {
    for (const [l, a, b] of links) { const [x1, y1] = P(a.u), [x2, y2] = P(b.u); l.setAttribute('x1', x1); l.setAttribute('y1', y1); l.setAttribute('x2', x2); l.setAttribute('y2', y2); }
    for (const [m, q, kind] of marksArr) { const [x, y] = P(q.u); if (kind === 'on') { m.setAttribute('x', x - 8); m.setAttribute('y', y - 8); } else { m.setAttribute('cx', x); m.setAttribute('cy', y); } }
  };
  sync();
  return {
    svg, fillPath, outline, handles, marks, items, pts, marksArr, links, P,
    redraw() { build(); sync(); },
    reveal(t, t0, t1) { // points pop in along the contour
      items.forEach((nodes, i) => {
        const a = t0 + (t1 - t0) * (i / items.length);
        const p = E.out3(prog(t, a, a + 0.25));
        nodes.forEach((n) => n.setAttribute('opacity', (p * (n.tagName === 'line' ? 0.9 : 1)).toFixed(3)));
      });
    },
    draw(t, t0, t1) { outline.setAttribute('stroke-dashoffset', (1 - E.io3(prog(t, t0, t1))).toFixed(4)); },
  };
}

const mono = (txt, style = '') => h('div', { style: `font-family:"Plex Mono",monospace;font-weight:400;font-size:22px;line-height:1.5;color:rgba(255,255,255,.62);white-space:nowrap;${style}`, text: txt });
const hair = (style) => h('div', { style: `position:absolute;${style}` });

A.Intro = function (tagline) {
  const G = A.GLYPHS;
  const root = h('div', { class: 'layer', style: `background:${INK}` });
  const shot = (bg) => { const el = h('div', { style: `position:absolute;inset:0;overflow:hidden;isolation:isolate;background:${bg}` }); root.appendChild(el); return el; };
  const T = { A: 0, B: 2.4, C: 4.0, D: 5.6, E: 7.2, F: 8.8 };
  const WIPE = 0.5;

  // ═══ A · the "a" ═════════════════════════════════════════════════════════
  const sA = shot(INK);
  const camA = h('div', { style: 'position:absolute;inset:0;transform-origin:1060px 560px' });
  const aS = 1.3, aOx = 1060 - ((G.a.bounds[0] + G.a.bounds[2]) / 2) * aS, aOy = 560 + ((G.a.bounds[1] + G.a.bounds[3]) / 2) * aS;
  const ga = glyph(G.a, { s: aS, ox: aOx, oy: aOy, fill: BLUE, stroke: WHITE, sw: 2.5 });
  const baseY = aOy, xhY = aOy - G.a.xh * aS;
  const metric = (y, label) => h('div', { style: `position:absolute;left:-400px;right:-400px;top:${y}px;height:0;border-top:1.5px solid rgba(255,255,255,.28)` },
    h('div', { style: 'position:absolute;right:560px;top:-34px;font-family:"Plex Mono";font-size:20px;color:rgba(255,255,255,.62)', text: label }));
  const mBase = metric(baseY, 'baseline  0'), mXh = metric(xhY, `x-height  ${G.a.xh}`);
  camA.append(mBase, mXh, ga.svg);
  // the control point the cursor drags: the outer shoulder of the bowl
  let grab = null;
  for (const [m, q, kind] of ga.marksArr) if (kind === 'off' && (!grab || q.u[1] > grab.q.u[1])) grab = { m, q };
  const grabHome = grab.q.u.slice();
  const specA = h('div', { style: 'position:absolute;left:92px;top:72px' },
    h('div', { style: 'font-family:"MontAS";font-weight:800;font-size:34px;color:#fff', text: 'Mont AS Heavy' }),
    mono('a   U+0061   ·   upm 1000', 'margin-top:10px'));
  const readout = mono('', 'position:absolute;left:92px;bottom:64px;color:#fff');
  const curA = pointer('User', GREEN, INK);
  sA.append(camA, specA, readout, curA.el);

  // ═══ B · the angle ═══════════════════════════════════════════════════════
  const sB = shot(INK);
  const field = h('div', { style: 'position:absolute;left:730px;top:0;right:0;bottom:0;background:#174482;overflow:hidden' });
  const sGx = 1325, sS = 1.9, sOx = sGx - ((G.S.bounds[0] + G.S.bounds[2]) / 2) * sS, sOy = 540 + ((G.S.bounds[1] + G.S.bounds[3]) / 2) * sS;
  const gs = glyph(G.S, { s: sS, ox: sOx - 730, oy: sOy, fill: 'rgba(255,255,255,.14)', stroke: WHITE, sw: 3, anchorFill: '#174482' });
  const slant = Math.abs(G.S.italic);
  const cx = sGx - 730, cy = 540;
  const skewBox = h('div', { style: `position:absolute;inset:0;transform-origin:${cx}px ${cy}px` }, gs.svg);
  const vert = hair(`left:${cx}px;top:-200px;height:1480px;width:0;border-left:2px dashed rgba(255,255,255,.5)`);
  const slantLine = hair(`left:${cx - 1.5}px;top:-200px;height:1480px;width:3px;background:${GREEN};transform-origin:1.5px 740px`);
  const R = 360;
  const arcSvg = sv('svg', { width: 1190, height: 1080, style: 'position:absolute;left:0;top:0;overflow:visible' });
  const arc = sv('path', { fill: 'none', stroke: GREEN, 'stroke-width': 3 });
  arcSvg.appendChild(arc);
  const deg = h('div', { style: `position:absolute;left:144px;top:650px;font-family:"MontAS";font-weight:800;font-size:220px;letter-spacing:-.04em;color:${GREEN};line-height:1` });
  field.append(skewBox, vert, slantLine, arcSvg);
  const specB = h('div', { style: 'position:absolute;left:144px;top:360px' },
    h('div', { style: 'font-family:"Sub XNarrow";font-weight:800;font-style:italic;font-size:112px;line-height:1;color:#fff', text: 'SportBILD' }),
    mono('display  ·  800 italic', 'margin-top:28px'),
    mono(`italicAngle  −${slant.toFixed(1)}°`),
    mono('stand-in  Sofia Sans Extra Condensed'));
  const curB = pointer('sportbild', WHITE, '#174482');
  sB.append(field, specB, deg, curB.el);

  // ═══ C · the colours ═════════════════════════════════════════════════════
  const sC = shot(INK);
  const WALL = { welt: '#2A3B67' };
  const live = A.BRANDS.filter((b) => !b.contentOnly);
  const barRow = h('div', { style: 'position:absolute;inset:0;display:flex' });
  const bars = live.map((b) => {
    const nm = h('div', { style: A.font(b.display) + 'position:absolute;left:34px;bottom:120px;font-size:52px;line-height:1;color:#fff;white-space:nowrap;writing-mode:vertical-rl;transform:rotate(180deg)', text: b.name });
    const hex = h('div', { style: 'position:absolute;left:34px;bottom:44px;font-family:"Plex Mono";font-size:19px;color:rgba(255,255,255,.85);white-space:nowrap', text: (WALL[b.key] || b.c).toUpperCase() });
    const el = h('div', { style: `position:relative;flex:1 1 0;min-width:0;overflow:hidden;background:${WALL[b.key] || b.c}` }, nm, hex);
    barRow.appendChild(el);
    return { el, b, hex };
  });
  const bild = bars.find((x) => x.b.key === 'bild');
  const tokenTag = h('div', { style: 'position:absolute;left:34px;top:64px;white-space:nowrap;opacity:0' },
    h('div', { style: 'font-family:"Plex Mono";font-size:22px;color:rgba(255,255,255,.75)', text: '--bg-color-brand-solid  →' }),
    h('div', { style: 'font-family:"MontAS";font-weight:800;font-size:64px;letter-spacing:-.02em;color:#fff;margin-top:12px', text: 'color-bild-red-50' }));
  bild.el.appendChild(tokenTag);
  const curC = pointer('User', GREEN, INK);
  sC.append(barRow, curC.el);

  // ═══ D · the specimen grid ═══════════════════════════════════════════════
  const sD = shot('#F6F6F6');
  const BR = A.BR;
  const cells = ['core', 'bild', 'sportbild', 'bz', 'welt', 'weltedition', 'advertorial', 'fitbook', 'travelbook', 'petbook'].map((k, i) => {
    const b = BR[k];
    const fillC = WALL[k] || b.c || INK;
    const flood = h('div', { style: `position:absolute;left:0;right:0;bottom:0;height:0;background:${fillC}` });
    const aa = h('div', { style: A.font(b.display) + 'position:absolute;left:34px;bottom:40px;font-size:220px;line-height:1;letter-spacing:-.01em;color:#0F0F0F', text: 'Aa' });
    const key = h('div', { style: 'position:absolute;left:34px;top:30px;font-family:"Plex Mono";font-size:20px;color:#0F0F0F;opacity:.7', text: k });
    const col = i % 5, row = Math.floor(i / 5);
    const el = h('div', { style: `position:absolute;left:${col * 384}px;top:${row * 540}px;width:384px;height:540px;overflow:hidden;box-shadow:inset -1px -1px 0 rgba(15,15,15,.18)` }, flood, aa, key);
    sD.appendChild(el);
    return { el, flood, aa, key };
  });
  const flipOrder = [3, 7, 0, 5, 9, 2, 6, 1, 8, 4];
  const curD = [pointer('bild', '#DD0000', WHITE), pointer('welt', '#2A3B67', WHITE), pointer('fitbook', '#B45068', WHITE)];
  curD.forEach((c) => sD.appendChild(c.el));
  const pathD = [
    track([[0, [1480, 1180]], [0.7, [1210, 640]], [1.6, [980, 560]]]),
    track([[0, [-200, 260]], [0.8, [470, 300]], [1.6, [620, 330]]]),
    track([[0.2, [900, -200]], [1.0, [1650, 180]], [1.6, [1720, 240]]]),
  ];

  // ═══ E + F · the wordmark ════════════════════════════════════════════════
  const sE = shot(INK);
  const letters = 'axis'.split('').map((c) => h('span', { style: 'display:inline-block', text: c }));
  const rest = ' design system'.split('').map((c) => h('span', { style: 'display:none;white-space:pre', text: c }));
  const caret = h('span', { style: `display:inline-block;width:.5em;height:.13em;margin-left:.15em;background:${GREEN}` });
  const mark = h('div', { style: 'position:absolute;left:151px;top:479px;font-family:"MontAS";font-weight:800;font-size:108px;line-height:1;letter-spacing:-.03em;white-space:nowrap;color:#fff;transform-origin:0 0' },
    h('span', { class: 'axisw' }, letters), rest, caret);
  const tag = h('div', { style: 'position:absolute;left:151px;top:633px;width:973px;font-family:"MontAS";font-weight:400;font-size:38px;line-height:1.25;letter-spacing:-.01em;color:#fff', text: tagline });
  const tagWrap = h('div', { style: 'position:absolute;inset:0;opacity:.7' }, tag);
  const logo = h('div', { class: 'logo', html: A.ASSETS.logoOnDark });
  sE.append(mark, tagWrap, logo);
  let M = null; // measured once fonts are in
  const measure = () => {
    const axisW = mark.querySelector('.axisw').offsetWidth;
    const k = 200 / 108;
    const xs = letters[1];
    M = { k, tx: 960 - (axisW * k) / 2 - 151, xMid: xs.offsetLeft + xs.offsetWidth / 2 };
  };

  const shots = [[sA, T.A], [sB, T.B], [sC, T.C], [sD, T.D], [sE, T.E]];
  const edge = h('div', { style: `position:absolute;top:0;bottom:0;width:14px;background:${GREEN};z-index:50;opacity:0` });
  root.appendChild(edge);

  return {
    el: root,
    render(t, Tdur) {
      if (!M) measure();
      // shot visibility + right-to-left wipes with a green leading edge
      let edgeX = null;
      shots.forEach(([el, a], i) => {
        const next = shots[i + 1] ? shots[i + 1][1] : Infinity;
        const vis = t >= a && t < next + WIPE;
        S(el, { display: vis ? 'block' : 'none' });
        if (!vis) return;
        if (i > 0 && t < a + WIPE) {
          const p = E.io5(prog(t, a, a + WIPE));
          S(el, { clipPath: `inset(0 0 0 ${((1 - p) * 100).toFixed(3)}%)` });
          edgeX = (1 - p) * 1920;
        } else S(el, { clipPath: 'none' });
      });
      S(edge, { opacity: edgeX == null ? '0' : '1', transform: `translateX(${((edgeX ?? 0) - 7).toFixed(1)}px)` });

      // A ─────────────────────────────────────────────────────────────────
      if (t < T.B + WIPE) {
        const lt = t - T.A;
        const z = lerp(1.34, 1.12, E.out3(prog(lt, 0, 2.6)));
        S(camA, { transform: `scale(${z.toFixed(4)})` });
        S(ga.fillPath, { opacity: E.out3(prog(lt, 0.0, 0.5)).toFixed(3) });
        ga.draw(lt, 0.1, 1.0);
        ga.reveal(lt, 0.25, 1.2);
        S(mBase, { opacity: E.out3(prog(lt, 0.2, 0.7)).toFixed(3) });
        S(mXh, { opacity: E.out3(prog(lt, 0.3, 0.8)).toFixed(3) });
        rise(specA, lt, 0.15, 0.6, 14);
        // drag: the shoulder control eases out and back, the outline follows
        const drag = E.io3(prog(lt, 1.55, 2.05)) - E.io3(prog(lt, 2.12, 2.4)) * 0.4;
        grab.q.u[0] = grabHome[0] + drag * 70; grab.q.u[1] = grabHome[1] + drag * 46;
        ga.redraw();
        const sel = lt >= 1.45;
        grab.m.setAttribute('fill', sel ? GREEN : WHITE);
        grab.m.setAttribute('r', sel ? 11 : 7);
        // pointer target in screen space (through the camera scale)
        const [gx, gy] = ga.P(grab.q.u);
        const sx = 1060 + (gx - 1060) * z, sy = 560 + (gy - 560) * z;
        const into = E.io3(prog(lt, 0.5, 1.4));
        curA.at(lerp(1750, sx - 8, into), lerp(1180, sy - 8, into), press(lt, 1.45));
        readout.textContent = `x ${Math.round(grab.q.u[0])}   y ${Math.round(grab.q.u[1])}`;
        S(readout, { opacity: E.out3(prog(lt, 1.45, 1.7)).toFixed(3) });
      }

      // B ─────────────────────────────────────────────────────────────────
      if (t >= T.B && t < T.C + WIPE) {
        const lt = t - T.B;
        const p = E.io5(prog(lt, 0.35, 1.15)); // upright → italic
        const ang = slant * p;
        S(skewBox, { transform: `skewX(${(slant * (1 - p)).toFixed(3)}deg)` });
        gs.draw(lt, 0.0, 0.7);
        gs.reveal(lt, 0.1, 0.8);
        S(slantLine, { transform: `rotate(${ang.toFixed(3)}deg)`, opacity: E.out3(prog(lt, 0.25, 0.45)).toFixed(3) });
        S(vert, { opacity: E.out3(prog(lt, 0.2, 0.4)).toFixed(3) });
        const r = (ang * Math.PI) / 180;
        arc.setAttribute('d', `M${cx} ${cy - R} A${R} ${R} 0 0 1 ${(cx + R * Math.sin(r)).toFixed(2)} ${(cy - R * Math.cos(r)).toFixed(2)}`);
        arc.setAttribute('opacity', ang > 0.2 ? '1' : '0');
        deg.textContent = `${ang.toFixed(0)}°`;
        S(deg, { opacity: E.out3(prog(lt, 0.35, 0.55)).toFixed(3) });
        rise(specB, lt, 0.2, 0.6, 16);
        // the pointer rides the top of the slanted guide
        const top = [730 + cx + Math.sin(r) * R, cy - Math.cos(r) * R];
        const into = E.io3(prog(lt, 0.0, 0.35));
        curB.at(lerp(1900, top[0] - 8, into), lerp(-60, top[1] - 8, into), press(lt, 0.35));
      }

      // C ─────────────────────────────────────────────────────────────────
      if (t >= T.C && t < T.D + WIPE) {
        const lt = t - T.C;
        bars.forEach((x, i) => {
          const p = E.io5(prog(lt, 0.05 + i * 0.045, 0.5 + i * 0.045));
          S(x.el, { transform: `translateY(${((1 - p) * -100).toFixed(2)}%)` });
        });
        const open = E.io5(prog(lt, 0.95, 1.45));
        S(bild.el, { flexGrow: (1 + open * 7).toFixed(3) });
        bars.forEach((x) => { if (x !== bild) S(x.hex, { opacity: (1 - open).toFixed(3) }); });
        rise(tokenTag, lt, 1.25, 0.45, 14);
        const bx = 192 * 1.5; // BILD is the second bar
        const into = E.io3(prog(lt, 0.3, 0.9));
        curC.at(lerp(1300, bx - 8, into), lerp(1180, 600, into), press(lt, 0.92));
      }

      // D ─────────────────────────────────────────────────────────────────
      if (t >= T.D && t < T.E + WIPE) {
        const lt = t - T.D;
        flipOrder.forEach((ci, j) => {
          const c = cells[ci];
          const p = E.io5(prog(lt, 0.3 + j * 0.085, 0.75 + j * 0.085));
          S(c.flood, { height: (p * 100).toFixed(2) + '%' });
          const on = p > 0.55;
          S(c.aa, { color: on ? '#FFFFFF' : '#0F0F0F' });
          S(c.key, { color: on ? '#FFFFFF' : '#0F0F0F' });
          rise(c.aa, lt, 0.05 + (ci % 5) * 0.04, 0.6, 30);
        });
        curD.forEach((c, i) => { const [x, y] = pathD[i](lt); c.at(x, y); });
      }

      // E + F ─────────────────────────────────────────────────────────────
      if (t >= T.E) {
        const lt = t - T.E;
        const tf = t - T.F; // F local
        // macro on the "x", pulling back to the whole word
        const zoom = lerp(7.5, 1, E.io5(prog(lt, 0.15, 1.35)));
        // wordmark travels from centre (200px) to the title position (108px)
        const mv = E.io5(prog(tf, 0.0, 0.85));
        const k = lerp(M.k, 1, mv), tx = lerp(M.tx, 0, mv);
        const px = M.tx + M.k * M.xMid, py = M.k * 108 * 0.6; // element-local (origin 0 0)
        S(mark, { transform: `translate(${px}px,${py}px) scale(${zoom.toFixed(4)}) translate(${-px}px,${-py}px) translate(${tx.toFixed(2)}px,0px) scale(${k.toFixed(4)})` });
        letters.forEach((l, i) => { if (i !== 1) rise(l, lt, 0.55 + (i > 1 ? i - 1 : i) * 0.09, 0.6, 40); });
        // "design system" types in; the green underscore is the caret
        const n = Math.max(0, Math.min(rest.length, Math.floor((tf - 0.7) * 24)));
        rest.forEach((r, i) => S(r, { display: i < n ? 'inline-block' : 'none' }));
        const typing = tf >= 0.7 && n < rest.length;
        const blink = !typing && tf < 1.6 && Math.floor(lt * 2.6) % 2 === 1;
        S(caret, { opacity: lt < 1.2 ? '0' : blink ? '0' : '1' });
        rise(tag, tf, 1.45, 0.8, 16);
        rise(logo, tf, 1.75, 0.7, 0);
      }
      S(root, { opacity: (1 - E.in3(prog(t, Tdur - 0.3, Tdur))).toFixed(3) });
    },
  };
};
