// ─────────────────────────────────────────────────────────────────────────────
// kit.js — presentation screens (Axel Springer Brand Manual) + the workspace
// ─────────────────────────────────────────────────────────────────────────────
const A = window.__axisFilm;
const { h, S, E, prog, clamp, lerp, win } = A;

// ── brand catalogue ─────────────────────────────────────────────────────────
// Order, keys and colours from build-config/pipeline.config.js and the token
// export (BrandTheme → bg-color-brand-light). Display and button type from
// BrandType, set in free lookalikes (see README).
const F = {
  mont: (w = 700) => ({ fam: '"MontAS"', w }),
  gotham: { fam: '"Sub Gotham"', w: 700 },
  gcond: { fam: '"Sub Gotham Condensed"', w: 700 },
  xnarrow: (w = 800) => ({ fam: '"Sub XNarrow"', w }),
  antenna: { fam: '"Sub XNarrow"', w: 800, st: 'italic' },
  sofia: { fam: '"Sofia Sans Condensed"', w: 800 },
  mark: (w = 800) => ({ fam: '"Sub Mark"', w }),
  freight: { fam: '"Sub Freight"', w: 400 },
  oswald: { fam: '"Oswald"', w: 700 },
  lucida: (w = 700) => ({ fam: '"Sub Lucida"', w }),
};
A.F = F;
A.font = (f) => `font-family:${f.fam};font-weight:${f.w};font-style:${f.st || 'normal'};`;

A.BRANDS = [
  { key: 'core', name: 'Core', c: '#0000FF', prim: 'color-core-blue-40', display: F.mont(700),
    button: { ...F.mont(700), size: 14, r: 4 } },
  { key: 'bild', name: 'BILD', c: '#DD0000', prim: 'color-bild-red-50', display: F.gotham,
    button: { ...F.xnarrow(700), size: 17, r: 8 } },
  { key: 'sportbild', name: 'SportBILD', c: '#174482', prim: 'color-spobi-blue-30', display: F.antenna,
    button: { ...F.antenna, size: 17, r: 8 } },
  { key: 'bz', name: 'B.Z.', c: '#DE0D22', prim: 'color-bz-red-50', display: F.sofia,
    button: { fam: '"Sofia Sans Condensed"', w: 700, size: 17, r: 4 } },
  { key: 'advertorial', name: 'Advertorial', contentOnly: true, display: F.lucida(700) },
  { key: 'welt', name: 'WELT', c: '#F18825', prim: 'color-welt-orange-50', display: F.mark(800),
    button: { ...F.mark(800), size: 14, r: 4 } },
  { key: 'weltedition', name: 'WELT Edition', contentOnly: true, display: F.freight },
  { key: 'fitbook', name: 'FITBOOK', c: '#B45068', prim: 'color-fitbook-rose-50', display: F.oswald,
    button: { ...F.oswald, size: 17, r: 4 } },
  { key: 'myhomebook', name: 'MYHOMEBOOK', c: '#008282', prim: 'color-myhomebook-teal-50', display: F.oswald },
  { key: 'petbook', name: 'PETBOOK', c: '#547D54', prim: 'color-petbook-green-50', display: F.oswald },
  { key: 'techbook', name: 'TECHBOOK', c: '#007E9E', prim: 'color-techbook-blue-50', display: F.oswald },
  { key: 'travelbook', name: 'TRAVELBOOK', c: '#008080', prim: 'color-travelbook-teal-50', display: F.oswald,
    button: { ...F.oswald, size: 17, r: 4 } },
];
A.UPCOMING = [
  { key: 'telegraph', name: 'The Telegraph' },
  { key: 'businessinsider', name: 'Business Insider' },
  { key: 'politico', name: 'POLITICO' },
];
A.BR = Object.fromEntries(A.BRANDS.map((b) => [b.key, b]));

// ── helpers ─────────────────────────────────────────────────────────────────
const US = (cls = '') => `<span class="us ${cls}"></span>`;
const svgEl = (markup, cls) => h('div', { class: cls, html: markup });

function headline(parts) {
  const rows = [];
  for (const p of [].concat(parts)) {
    const row = h('div', { class: 'wrow' });
    if (typeof p === 'string') p.split(' ').forEach((w) => row.appendChild(h('span', { class: 'w', text: w + ' ' })));
    else p.em.split(' ').forEach((w) => row.appendChild(h('span', { class: 'w em', text: w + ' ' })));
    rows.push(row);
  }
  const el = h('div', { class: 'headline' }, rows);
  return { el, spans: [...el.querySelectorAll('.w')] };
}
function rise(el, t, t0, dur = 0.7, dy = 26) {
  const p = E.out5(prog(t, t0, t0 + dur));
  S(el, { opacity: p.toFixed(3), transform: `translateY(${((1 - p) * dy).toFixed(2)}px)` });
}
function reveal(spans, t, t0, stagger = 0.07, dur = 0.7) {
  spans.forEach((s, i) => rise(s, t, t0 + i * stagger, dur, 32));
}
function footer(bold = false) {
  return h('div', { class: 'footer' }, svgEl(A.ASSETS.logoShort, 'fl'), h('span', { style: bold ? 'font-weight:700' : null, text: 'Axis Design System' }));
}

// ── screens ─────────────────────────────────────────────────────────────────

// Opener: dark (as in the Axis Design Tools films). Logo top left, introductory
// only (Manual 2.1 landscape placement). Wordmark set as Impuls type.
A.TitleCard = function (tagline) {
  const logo = svgEl(A.ASSETS.logoOnDark, 'logo');
  const mark = h('div', { class: 'wordmark', style: 'font-size:156px;white-space:nowrap', html: 'axis design system' + US('g') });
  const tag = h('div', { class: 'copy', style: 'margin-top:46px;font-size:46px', text: tagline });
  const el = h('div', { class: 'layer' }, h('div', { class: 'scr dark' }, logo,
    h('div', { class: 'block', style: 'top:440px' }, mark, tag)));
  return {
    el,
    render(t, T) {
      rise(logo, t, 0.05, 0.6, 0);
      rise(mark, t, 0.25, 1.0, 26);
      rise(tag, t, 1.3, 0.8, 18);
      S(el, { opacity: (1 - E.in3(prog(t, T - 0.35, T))).toFixed(3) });
    },
  };
};

// Statement: light, label + headline, flush left.
A.Statement = function (label, parts, opts = {}) {
  const lb = h('div', { class: 'label', html: label + US() });
  const { el: hl, spans } = headline(parts);
  const el = h('div', { class: 'layer' }, h('div', { class: 'scr light' },
    h('div', { class: 'block', style: 'top:338px' }, lb, h('div', { style: 'margin-top:52px' }, hl)),
    footer(opts.boldFooter)));
  return {
    el,
    render(t) {
      rise(lb, t, 0.08, 0.6, 16);
      reveal(spans, t, 0.4);
    },
  };
};

// Act card: a near-black field with the section in Impuls type, green underscore.
A.Flash = function (num, label, sub) {
  const n = h('div', { class: 'label', style: 'font-size:36px;font-weight:400', text: num });
  const nWrap = h('div', { style: 'opacity:.7' }, n);
  const t1 = h('div', { class: 'wordmark', style: 'font-size:164px;margin-top:26px', html: label + US('g') });
  const s = h('div', { class: 'copy', text: sub });
  const sWrap = h('div', { style: 'margin-top:8px;opacity:.7' }, s);
  const el = h('div', { class: 'layer' }, h('div', { class: 'scr', style: 'background:#050505;color:#fff' },
    h('div', { class: 'block', style: 'top:544px' }, nWrap, t1, sWrap)));
  return {
    el,
    render(t) {
      rise(n, t, 0, 0.35, 10);
      rise(t1, t, 0.02, 0.4, 18);
      rise(s, t, 0.18, 0.45, 14);
    },
  };
};

// Brand wall: each publication set in its own typeface, on its own brand colour.
A.BrandWall = function () {
  const lb = h('div', { class: 'label', html: 'the brands' + US() });
  const hl = h('div', { class: 'headline', style: 'font-size:76px;margin-top:34px' },
    h('span', { text: 'Ten publications. ' }), h('b', { text: 'One system.' }));
  const PLATFORM = { core: 'web + app', bild: 'web + app', bz: 'web + app', welt: 'web + app' };
  const WALL_COLOR = { welt: '#2A3B67' };
  const tile = (b) => {
    const size = { myhomebook: 44, travelbook: 44, techbook: 44 }[b.key] || 46;
    return h('div', { class: 'tile', style: `background:${WALL_COLOR[b.key] || b.c}` },
      h('div', { class: 'key', text: PLATFORM[b.key] || 'web' }),
      h('div', { class: 'nm', style: A.font(b.display) + `font-size:${size}px`, text: b.name }));
  };
  const live = A.BRANDS.filter((b) => !b.contentOnly).map(tile);
  const next = A.UPCOMING.map((b) => h('div', { class: 'tile next' },
    h('div', { class: 'key', text: 'web + app' }),
    h('div', { class: 'nm', style: 'font-family:"MontAS";font-weight:400;font-size:34px', text: b.name })));
  const grid = h('div', { class: 'tiles', style: 'margin-top:70px' }, ...live, ...next);
  const el = h('div', { class: 'layer' }, h('div', { class: 'scr light' },
    h('div', { class: 'block', style: 'top:150px' }, lb, hl, grid), footer()));
  return {
    el,
    render(t) {
      rise(lb, t, 0.08, 0.6, 16);
      rise(hl, t, 0.3, 0.7, 22);
      live.forEach((c, i) => rise(c, t, 0.7 + i * 0.075, 0.6, 20));
      next.forEach((c, i) => rise(c, t, 3.6 + i * 0.2, 0.6, 20));
    },
  };
};

// Results: numbers carry the screen; Ink Blue figures, black copy.
A.Results = function (items) {
  const lb = h('div', { class: 'label', html: 'the result' + US() });
  const cols = items.map(([n, html]) => h('div', { class: 'stat' },
    h('div', { class: 'n', text: n }), h('div', { class: 't', html })));
  const el = h('div', { class: 'layer' }, h('div', { class: 'scr light' },
    h('div', { class: 'block', style: 'top:262px' }, lb, h('div', { class: 'stats', style: 'margin-top:78px' }, cols)),
    footer()));
  return {
    el,
    render(t) {
      rise(lb, t, 0.08, 0.6, 16);
      cols.forEach((c, i) => rise(c, t, 0.4 + i * 0.22, 0.8, 30));
    },
  };
};

// Outro: dark; no logo (the manual places it only at the opening).
A.Outro = function () {
  const mark = h('div', { class: 'wordmark', style: 'font-size:108px;white-space:nowrap', html: 'axis design system' + US('g') });
  const names = A.BRANDS.filter((b) => !b.contentOnly && b.key !== 'core').map((b) =>
    h('span', { style: A.font(b.display) + 'font-size:31px;color:#fff;white-space:nowrap', text: b.name }));
  const row = h('div', { style: 'display:flex;flex-wrap:nowrap;gap:38px;margin-top:50px;align-items:baseline' }, names);
  const el = h('div', { class: 'layer' }, h('div', { class: 'scr dark' },
    h('div', { class: 'block', style: 'top:450px' }, mark, row)));
  return {
    el,
    render(t, T) {
      rise(mark, t, 0.15, 0.9, 22);
      names.forEach((n, i) => {
        const p = E.out5(prog(t, 0.9 + i * 0.07, 1.5 + i * 0.07));
        S(n, { opacity: (p * 0.92).toFixed(3), transform: `translateY(${((1 - p) * 14).toFixed(1)}px)` });
      });
      S(el, { opacity: (1 - E.in3(prog(t, T - 0.45, T))).toFixed(3) });
    },
  };
};

// ── workspace ───────────────────────────────────────────────────────────────
const CURSOR_SVG = `<svg viewBox="0 0 24 24" fill="none"><path d="M5.5 2.8 19 12.4l-6.2.6-3.1 6.6z" fill="#fff" stroke="#111" stroke-width="1.5" stroke-linejoin="round"/></svg>`;

A.Workspace = function (opts = {}) {
  const world = h('div', { class: 'world' }, h('div', { class: 'canvas' }));
  const cursor = h('div', { class: 'cursor' }, h('div', { html: CURSOR_SVG }), h('div', { class: 'name', text: opts.who || 'User' }));
  const cap = h('div', { class: 'cap' });
  const tag = h('div', { class: 'tag' });
  const ripple = h('div', { class: 'ripple' });
  const el = h('div', { class: 'layer' }, world, ripple, cursor, tag, cap);
  let camM = [0, 0, 1];

  const ws = {
    el, world, cursor, cap, tag, R: {},
    add(node) { world.appendChild(node); return node; },
    // geometry is measured once, before anything is transformed
    measure() {
      const wr = world.getBoundingClientRect();
      const sc = wr.width / 1920 || 1;
      ws.R = {};
      for (const n of world.querySelectorAll('[data-a]')) {
        const r = n.getBoundingClientRect();
        ws.R[n.getAttribute('data-a')] = { x: (r.left - wr.left) / sc, y: (r.top - wr.top) / sc, w: r.width / sc, h: r.height / sc };
      }
    },
    a(anchor, fx = 0.5, fy = 0.5, dx = 0, dy = 0) {
      const r = ws.R[anchor];
      if (!r) return [960, 540];
      return [r.x + r.w * fx + dx, r.y + r.h * fy + dy];
    },
    cam(t, camTrack, clicks = []) {
      const [cx, cy, z] = camTrack(t);
      let punch = 0;
      for (const ct of clicks) if (t >= ct) punch += 0.01 * (1 - E.outX(prog(t, ct, ct + 0.45)));
      const zz = z * (1 + punch);
      camM = [960 - cx * zz, 540 - cy * zz, zz];
      S(tag, { opacity: (1 - E.out3(prog(t, 1.0, 1.5))).toFixed(3) });
      S(world, { transform: `translate(${camM[0].toFixed(2)}px, ${camM[1].toFixed(2)}px) scale(${zz.toFixed(4)})` });
    },
    point(t, keys, clicks = []) {
      let pos = keys[0].p;
      for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        if (t >= k.t) { pos = k.p; continue; }
        const prev = i ? keys[i - 1] : k;
        const d = k.d != null ? k.d : 0.5;
        const p = E.io3(prog(t, k.t - d, k.t));
        pos = [lerp(prev.p[0], k.p[0], p), lerp(prev.p[1], k.p[1], p)];
        break;
      }
      const sx = camM[0] + pos[0] * camM[2], sy = camM[1] + pos[1] * camM[2];
      let press = 0;
      for (const ct of clicks) press = Math.max(press, win(t, ct, ct + 0.22, 0.06, 0.14, 'out3'));
      // tilt from velocity, sampled deterministically
      const dt = 1 / 60;
      let prevX = sx;
      { let pp = keys[0].p;
        const tt = t - dt;
        for (let i = 0; i < keys.length; i++) { const k = keys[i]; if (tt >= k.t) { pp = k.p; continue; }
          const prev = i ? keys[i - 1] : k; const d = k.d != null ? k.d : 0.5; const q = E.io3(prog(tt, k.t - d, k.t));
          pp = [lerp(prev.p[0], k.p[0], q), lerp(prev.p[1], k.p[1], q)]; break; }
        prevX = camM[0] + pp[0] * camM[2]; }
      const tilt = clamp((sx - prevX) * 0.35, -8, 8);
      const vis = opts.hideCursorBefore != null && t < opts.hideCursorBefore ? 0 : 1;
      S(cursor, { opacity: String(vis), transform: `translate(${sx.toFixed(2)}px, ${sy.toFixed(2)}px) scale(${(2.25 * (1 - press * 0.12)).toFixed(3)}) rotate(${tilt.toFixed(2)}deg)` });
      let rp = 0;
      for (const ct of clicks) if (t >= ct && t - ct < 0.6) rp = prog(t, ct, ct + 0.6);
      if (rp > 0) {
        const sz = 30 + E.out3(rp) * 110;
        S(ripple, { opacity: (1 - rp).toFixed(3), width: sz + 'px', height: sz + 'px', transform: `translate(${(sx - sz / 2).toFixed(1)}px, ${(sy - sz / 2).toFixed(1)}px)` });
      } else S(ripple, { opacity: '0' });
    },
    caption(t, list) {
      let cur = null;
      for (const c of list) if (t >= c[0] && t < c[1]) cur = c;
      if (!cur) { S(cap, { opacity: '0' }); return; }
      const [a, b, n, txt] = cur;
      if (cap.__k !== txt) { cap.__k = txt; cap.innerHTML = `<span class="n">${n}</span>${txt}<span class="us"></span>`; }
      const o = Math.min(E.out5(prog(t, a, a + 0.3)), 1 - E.in3(prog(t, b - 0.22, b)));
      S(cap, { opacity: o.toFixed(3), transform: `translateY(${((1 - o) * 12).toFixed(1)}px)` });
    },
    setTag(html) { tag.innerHTML = html; S(tag, { display: html ? 'block' : 'none' }); },
  };
  return ws;
};
