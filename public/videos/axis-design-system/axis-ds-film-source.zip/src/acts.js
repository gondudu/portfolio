// ─────────────────────────────────────────────────────────────────────────────
// acts.js — five demos, each a small, tasteful abstraction of how the system
// actually works. Every name, value and label is still taken from the
// axis-design-system repo — only the chrome (Figma, browser, VS Code, GitHub)
// has been put aside in favour of a simple diagram that carries the idea.
// ─────────────────────────────────────────────────────────────────────────────
const A = window.__axisFilm;
const { h, S, E, prog, track, typed } = A;
const U = A.ui;
const BR = A.BR;
A.acts = {};

const rise = (el, t, t0, dur = 0.7, dy = 24) => {
  const p = E.out5(prog(t, t0, t0 + dur));
  S(el, { opacity: p.toFixed(3), transform: `translateY(${((1 - p) * dy).toFixed(1)}px)` });
};
const fadeOut = (el, t, t0, dur = 0.25) => {
  const p = 1 - E.out3(prog(t, t0, t0 + dur));
  S(el, { opacity: p.toFixed(3), visibility: p <= 0.001 ? 'hidden' : 'visible' });
};
const show = (el, on) => S(el, { visibility: on ? 'visible' : 'hidden' });
const tag = (ws, page) => ws.setTag(`axis design system <span class="sep">/</span><span class="pg">${page}</span>`);

// shared visual language: a plain card, a mono label, a colour swatch —
// the same few shapes, recombined for each idea.
const swatch = (hex, size = 28, r = 7) => h('span', { style: `display:inline-block;width:${size}px;height:${size}px;border-radius:${r}px;background:${hex};box-shadow:inset 0 0 0 1px rgba(0,0,0,.12);flex:none` });
const mono = (txt, size = 18, color = '#6B6B6B') => h('span', { style: `font-family:var(--mono);font-size:${size}px;color:${color}`, text: txt });
const staticCam = () => track([[0, [960, 540, 1.03]], [0.9, [960, 540, 1.0], 'io5'], [30, [960, 540, 1.0], 'lin']]);

// ═════════════════════════════════════════════════════════════════════════════
// ACT 1 — tokens · one chain, four layers, resolved per brand
// ═════════════════════════════════════════════════════════════════════════════
A.acts.tokens = function (ws) {
  const LAYERS = [
    { name: 'button-primary-brand-bg-color-idle', sub: 'component' },
    { name: 'bg-color-brand-solid', sub: 'semantic · Mode' },
    { name: 'bg-color-brand-light', sub: 'brand · BrandTheme' },
  ];
  const W = 620, H = 92, GAP = 22, X = 960 - W / 2, Y0 = 140;
  const pillEl = (i, name, sub) => {
    const y = Y0 + i * (H + GAP);
    const sw = swatch('#DD0000', 32, 8);
    const nameEl = h('div', { style: 'font-family:var(--mono);font-size:23px;color:#14161C', text: name });
    const subEl = h('div', { style: 'font-family:var(--mono);font-size:15px;color:#9A9A9A;margin-top:4px', text: sub });
    const el = h('div', { 'data-a': 'pill' + i, style: `position:absolute;left:${X}px;top:${y}px;width:${W}px;height:${H}px;background:#fff;border-radius:14px;box-shadow:0 0 0 1px rgba(0,0,0,.1),0 18px 40px rgba(20,22,30,.12);display:flex;align-items:center;gap:20px;padding:0 26px;box-sizing:border-box` }, sw, h('div', null, nameEl, subEl));
    return { el, sw, nameEl, subEl };
  };
  const pills = LAYERS.map((L, i) => pillEl(i, L.name, L.sub));
  const p3 = pillEl(3, 'color-bild-red-50', '#DD0000  ·  primitive');
  pills.push(p3);
  const arrows = [0, 1, 2].map((i) => {
    const y = Y0 + i * (H + GAP) + H;
    return h('div', { style: `position:absolute;left:960px;top:${y}px;width:0;height:${GAP}px;border-left:2px solid #C7CBD6` },
      h('div', { style: 'position:absolute;left:-5px;bottom:-2px;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-top:8px solid #C7CBD6' }));
  });
  const chain = h('div', { style: 'position:absolute;inset:0' }, ...pills.map((p) => p.el), ...arrows);

  const order = ['bild', 'core', 'welt', 'sportbild', 'bz'];
  const CW = 136, CH = 64, CGAP = 18, totalW = order.length * CW + (order.length - 1) * CGAP, CX0 = 960 - totalW / 2, CY = 706;
  const chips = order.map((k, i) => {
    const b = BR[k];
    const x = CX0 + i * (CW + CGAP);
    const dot = h('span', { style: `width:16px;height:16px;border-radius:4px;background:${b.c};flex:none` });
    const lab = h('span', { style: 'font-family:var(--mono);font-size:16px;color:#14161C', text: b.key });
    const el = h('div', { 'data-a': 'chip-' + k, style: `position:absolute;left:${x}px;top:${CY}px;width:${CW}px;height:${CH}px;border-radius:12px;background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.1);display:flex;align-items:center;justify-content:center;gap:10px;box-sizing:border-box` }, dot, lab);
    return { el, b, k };
  });
  const chipRow = h('div', { style: 'position:absolute;inset:0' }, ...chips.map((c) => c.el));

  const ALL = ['core', 'bild', 'sportbild', 'bz', 'welt', 'fitbook'];
  const btnRow = h('div', { style: 'position:absolute;left:144px;right:144px;top:470px;display:flex;justify-content:center;align-items:center;gap:40px' },
    ...ALL.map((k) => h('div', { 'data-a': 'btn-' + k }, U.dsButton(BR[k], 1.9))));

  ws.add(chain); ws.add(chipRow); ws.add(btnRow);
  tag(ws, 'tokens');

  const camT = staticCam();
  const clicks = [4.9, 5.9, 6.9, 7.8];

  return function render(t) {
    ws.cam(t, camT, clicks);
    rise(chain, t, 0.08, 0.6, 20);

    const phase2 = t >= 4.2, phase3 = t >= 8.6;
    if (phase3) { fadeOut(chain, t, 8.6, 0.3); fadeOut(chipRow, t, 8.6, 0.25); rise(btnRow, t, 8.75, 0.6, 24); }
    else if (phase2) { rise(chipRow, t, 4.2, 0.5, 16); S(btnRow, { opacity: '0', visibility: 'hidden' }); }
    else { S(chipRow, { opacity: '0', visibility: 'hidden' }); S(btnRow, { opacity: '0', visibility: 'hidden' }); }

    let idx = 0; for (const c of clicks) if (t >= c) idx++;
    const active = order[Math.min(idx, order.length - 1)];
    const b = BR[active];
    p3.nameEl.textContent = b.prim;
    p3.subEl.textContent = b.c + '  ·  primitive';
    [p3.sw, pills[0].sw, pills[1].sw, pills[2].sw].forEach((sw) => S(sw, { background: b.c }));
    chips.forEach((c) => S(c.el, { boxShadow: c.k === active ? `0 0 0 2px ${c.b.c}, 0 18px 40px rgba(20,22,30,.14)` : '0 0 0 1px rgba(0,0,0,.1)' }));

    ws.point(t, [
      { t: 0, p: [1500, 980], d: 0.01 },
      { t: 1.0, p: ws.a('pill0', 0.18, 0.5), d: 1.1 },
      { t: 2.2, p: ws.a('pill1', 0.18, 0.5), d: 0.9 },
      { t: 3.1, p: ws.a('pill2', 0.18, 0.5), d: 0.9 },
      { t: 4.5, p: ws.a('chip-bild', 0.5, 0.5), d: 0.9 },
      { t: 5.5, p: ws.a('chip-core', 0.5, 0.5), d: 0.9 },
      { t: 6.5, p: ws.a('chip-welt', 0.5, 0.5), d: 0.9 },
      { t: 7.4, p: ws.a('chip-sportbild', 0.5, 0.5), d: 0.7 },
      { t: 8.2, p: ws.a('chip-bz', 0.5, 0.5), d: 0.6 },
      { t: 9.0, p: ws.a('btn-bild', 0.5, 1.3), d: 1.0 },
      { t: 13, p: ws.a('btn-welt', 0.5, 1.3), d: 2.5 },
    ], clicks);

    ws.caption(t, [
      [0.8, 4.1, '01', 'a component token points at a semantic one'],
      [4.2, 8.5, '02', 'the brand mapping gives each brand its own primitive'],
      [8.6, 13, '03', 'one component, every brand'],
    ]);
  };
};

// ═════════════════════════════════════════════════════════════════════════════
// ACT 2 — theming · four attributes, one card
// ═════════════════════════════════════════════════════════════════════════════
A.acts.theming = function (ws) {
  const page = U.teaser();
  const cardWrap = h('div', { style: 'position:absolute;left:486px;top:170px;width:948px;height:760px;background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 0 0 1px rgba(0,0,0,.08),0 30px 70px rgba(20,22,30,.18)' }, page.el);

  const CONTROLS = [
    { attr: 'data-color-brand', a: 'tag-color' },
    { attr: 'data-content-brand', a: 'tag-content' },
    { attr: 'data-density', a: 'tag-density' },
    { attr: 'data-theme', a: 'tag-theme' },
  ];
  const tags = CONTROLS.map((c) => {
    const v = h('span', { style: 'color:#0000FF;font-weight:600;margin-left:2px', text: '""' });
    const el = h('div', { 'data-a': c.a, style: 'background:#fff;border-radius:10px;padding:14px 20px;box-shadow:0 0 0 1px rgba(0,0,0,.1);font-family:var(--mono);font-size:19px;color:#14161C;white-space:nowrap' },
      h('span', { text: c.attr + '=' }), v);
    return { el, v };
  });
  const tagsRow = h('div', { style: 'position:absolute;left:144px;right:144px;top:96px;display:flex;justify-content:center;gap:24px' }, ...tags.map((x) => x.el));

  const cssLine = h('div', { style: 'position:absolute;left:0;right:0;bottom:120px;display:flex;flex-direction:column;align-items:center;gap:8px;font-family:var(--mono);font-size:22px;color:#6B6B6B' },
    h('div', null, mono('background: ', 22, '#6B6B6B'), mono('var(--bg-color-primary)', 22, '#0000FF'), mono(';', 22, '#6B6B6B')),
    h('div', null, mono('color: ', 22, '#6B6B6B'), mono('var(--text-color-primary)', 22, '#0000FF'), mono(';', 22, '#6B6B6B')));

  ws.add(cardWrap); ws.add(tagsRow); ws.add(cssLine);
  tag(ws, 'theming');
  const camT = staticCam();
  const clicks = [3.0, 5.92, 8.6, 10.8];

  return function render(t) {
    ws.cam(t, camT, clicks);
    rise(cardWrap, t, 0.05, 0.6, 20);
    rise(tagsRow, t, 0.15, 0.6, 16);

    const color = t >= 3.0 ? 'sportbild' : 'bild';
    const content = t >= 5.92 ? 'advertorial' : 'bild';
    const density = t >= 8.6 ? 'dense' : 'default';
    const theme = t >= 10.8 ? 'dark' : 'light';
    page.apply({ color, content, density, theme });
    tags[0].v.textContent = `"${color}"`;
    tags[1].v.textContent = `"${content}"`;
    tags[2].v.textContent = `"${density}"`;
    tags[3].v.textContent = `"${theme}"`;
    const flash = (i, t0) => S(tags[i].el, { boxShadow: (t >= t0 && t < t0 + 0.4) ? '0 0 0 2px #0000FF' : '0 0 0 1px rgba(0,0,0,.1)' });
    flash(0, 3.0); flash(1, 5.92); flash(2, 8.6); flash(3, 10.8);

    if (t >= 12.72) rise(cssLine, t, 12.72, 0.5, 14); else S(cssLine, { opacity: '0', visibility: 'hidden' });

    ws.point(t, [
      { t: 0, p: [700, 990], d: 0.01 },
      { t: 2.4, p: ws.a('tag-color', 0.5, 0.5), d: 1.0 },
      { t: 5.3, p: ws.a('tag-content', 0.5, 0.5), d: 1.0 },
      { t: 8.0, p: ws.a('tag-density', 0.5, 0.5), d: 0.9 },
      { t: 10.2, p: ws.a('tag-theme', 0.5, 0.5), d: 0.9 },
      { t: 12.72, p: [960, 900], d: 0.8 },
      { t: 15, p: [960, 920], d: 1.5 },
    ], clicks);

    ws.caption(t, [
      [0.8, 2.95, '01', 'one page, four attributes on &lt;html&gt;'],
      [3.0, 5.85, '02', 'colour brand: bild to sportbild'],
      [5.92, 8.55, '03', 'content brand: advertorial brings its own type, keeps the colours'],
      [8.6, 10.75, '04', 'density: spacing only'],
      [10.8, 12.65, '05', 'theme: light to dark'],
      [12.72, 15, '06', 'the css never changed'],
    ]);
  };
};

// ═════════════════════════════════════════════════════════════════════════════
// ACT 3 — styleguide · one component, every brand, one set of foundations
// ═════════════════════════════════════════════════════════════════════════════
A.acts.styleguide = function (ws) {
  const order = ['core', 'bild', 'sportbild', 'bz', 'welt'];
  const CW = 196, CH = 64, CGAP = 18, totalW = order.length * CW + (order.length - 1) * CGAP, CX0 = 960 - totalW / 2;
  const tabs = order.map((k, i) => {
    const b = BR[k];
    const x = CX0 + i * (CW + CGAP);
    const dot = h('span', { style: `width:16px;height:16px;border-radius:4px;background:${b.c};flex:none` });
    const lab = h('span', { style: 'font-family:var(--mono);font-size:16px;color:#14161C', text: b.key });
    const el = h('div', { 'data-a': 'tab-' + k, style: `position:absolute;left:${x}px;top:168px;width:${CW}px;height:${CH}px;border-radius:12px;background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.1);display:flex;align-items:center;justify-content:center;gap:10px;box-sizing:border-box` }, dot, lab);
    return { el, b, k };
  });
  const tabRow = h('div', { style: 'position:absolute;inset:0' }, ...tabs.map((x) => x.el));

  const title = h('div', { style: 'position:absolute;left:0;right:0;top:80px;text-align:center;font-family:"MontAS";font-weight:800;font-size:30px;color:#9A9A9A', text: 'Button' });
  const btnHost = h('div', { style: 'position:absolute;left:0;right:0;top:400px;display:flex;justify-content:center' });
  const specsWrap = h('div', { style: 'position:absolute;left:0;right:0;top:620px;display:flex;justify-content:center;gap:56px' });
  const propRow = (k, v) => h('div', { style: 'display:flex;flex-direction:column;align-items:center;gap:6px' },
    mono(k, 15, '#9A9A9A'), h('span', { style: 'font-family:var(--mono);font-size:21px;color:#14161C', text: v }));

  const swatches = h('div', { style: 'position:absolute;left:0;right:0;top:330px;display:flex;justify-content:center;gap:28px' });

  ws.add(tabRow); ws.add(title); ws.add(btnHost); ws.add(specsWrap); ws.add(swatches);
  tag(ws, 'storybook');
  const camT = staticCam();
  const clicks = [5.35, 9.72];

  const specRows = { variant: propRow('variant', 'primary-brand'), label: propRow('label', 'Weiterlesen'), radius: propRow('radius', '0') };
  specsWrap.append(specRows.variant, specRows.label, specRows.radius);

  return function render(t) {
    ws.cam(t, camT, clicks);
    rise(tabRow, t, 0.05, 0.5, 18);

    const onFoundations = t >= 9.72;
    const active = t >= 5.35 ? 'welt' : 'bild';
    tabs.forEach((x) => S(x.el, { boxShadow: x.k === active && !onFoundations ? `0 0 0 2px ${x.b.c}` : '0 0 0 1px rgba(0,0,0,.1)' }));

    show(title, !onFoundations); show(btnHost, !onFoundations); show(specsWrap, !onFoundations);
    show(swatches, onFoundations);

    if (!onFoundations) {
      const b = BR[active];
      if (btnHost.__k !== active) { btnHost.__k = active; btnHost.innerHTML = ''; btnHost.appendChild(U.dsButton(b, 3.0)); }
      specRows.radius.lastChild.textContent = String(b.button.r);
      rise(btnHost, t, 0.3, 0.6, 20);
      rise(specsWrap, t, 0.5, 0.6, 18);
    } else {
      title.textContent = 'Foundations · Colors';
      if (swatches.__built !== true) {
        swatches.__built = true;
        const rows = [['text-color-brand', '#F18825'], ['bg-color-brand-light', '#F18825'], ['text-color-brand-light-only', '#FFFFFF']];
        rows.forEach(([name, hex]) => swatches.appendChild(h('div', { style: 'display:flex;flex-direction:column;align-items:center;gap:14px' }, swatch(hex, 64, 12), mono(name, 15, '#9A9A9A'))));
      }
      rise(swatches, t, 9.9, 0.6, 20);
    }

    ws.point(t, [
      { t: 0, p: [1500, 990], d: 0.01 },
      { t: 2.3, p: [1260, 650], d: 1.3 },
      { t: 4.3, p: ws.a('tab-welt', 0.5, 0.6), d: 1.2 },
      { t: 6.0, p: [1260, 460], d: 1.0 },
      { t: 8.6, p: [1260, 700], d: 1.2 },
      { t: 10.8, p: [1660, 820], d: 1.0 },
      { t: 13, p: [1670, 840], d: 1.6 },
    ], clicks);

    ws.caption(t, [
      [0.8, 3.95, '01', 'every component, documented with its props'],
      [4.05, 6.75, '02', 'colour brand: bild to welt'],
      [6.85, 9.4, '03', 'content brand: type and shape follow'],
      [9.5, 13, '04', 'foundation pages read the same tokens'],
    ]);
  };
};

// ═════════════════════════════════════════════════════════════════════════════
// ACT 4 — pipeline · one value, travelling from Figma to release
// ═════════════════════════════════════════════════════════════════════════════
A.acts.pipeline = function (ws) {
  const LABELS = ['Figma', 'Sync', 'Pull request', 'Checks', 'Release'];
  const nodeX = [224, 592, 960, 1328, 1696], NY = 460, ND = 118;
  const rail = h('div', { style: 'position:absolute;left:224px;right:224px;top:' + (NY + ND / 2 - 2) + 'px;height:4px;background:#E2E5EC;border-radius:2px' });
  const nodes = LABELS.map((lab, i) => {
    const circle = h('div', { style: `width:${ND}px;height:${ND}px;border-radius:50%;background:#fff;box-shadow:0 0 0 1px rgba(0,0,0,.1),0 18px 40px rgba(20,22,30,.12);display:flex;align-items:center;justify-content:center` });
    const sub = h('div', { style: 'position:absolute;left:' + nodeX[i] + 'px;top:' + (NY + ND + 18) + 'px;transform:translateX(-50%);font-family:"MontAS";font-weight:700;font-size:21px;color:#14161C;white-space:nowrap', text: lab });
    const el = h('div', { 'data-a': 'node' + i, style: `position:absolute;left:${nodeX[i] - ND / 2}px;top:${NY}px` }, circle);
    return { el, sub, circle };
  });
  const nodeLayer = h('div', { style: 'position:absolute;inset:0' }, rail, ...nodes.map((n) => n.el), ...nodes.map((n) => n.sub));

  const traveler = h('div', { style: 'position:absolute;top:' + (NY + ND / 2 - 19) + 'px;width:38px;height:38px;border-radius:50%;background:#0000FF;box-shadow:0 0 0 7px rgba(0,0,255,.15)' });

  const hexChip_sw = swatch('#DD0000', 26, 6);
  const hexChip_val = mono('#DD0000', 21, '#14161C');
  const hexChip = h('div', { style: 'position:absolute;left:50%;top:' + (NY - 90) + 'px;transform:translateX(-50%);background:#fff;border-radius:12px;padding:12px 22px;box-shadow:0 0 0 1px rgba(0,0,0,.1);display:flex;align-items:center;gap:12px' },
    hexChip_sw, hexChip_val);

  const diffChip = h('div', { style: 'position:absolute;left:50%;top:' + (NY - 86) + 'px;transform:translateX(-50%);font-family:var(--mono);font-size:19px;white-space:nowrap' },
    h('span', { style: 'color:#1A7F37;font-weight:700', text: '+1 ' }), h('span', { style: 'color:#D1242F;font-weight:700', text: '−1' }));

  const checksChip = h('div', { style: 'position:absolute;left:50%;top:' + (NY - 86) + 'px;transform:translateX(-50%);font-family:var(--mono);font-size:21px;color:#1A7F37;font-weight:700', text: '7 / 7' });

  const releaseRow = h('div', { style: 'position:absolute;left:0;right:0;top:720px;display:flex;justify-content:center;gap:16px;flex-wrap:nowrap' });
  const relChip = (txt, changed) => h('div', { style: `padding:10px 18px;border-radius:10px;font-family:var(--mono);font-size:17px;white-space:nowrap;${changed ? 'background:#E7F8EC;color:#1A7F37' : 'background:#F2F4F5;color:#9A9A9A'}`, text: txt });
  [['tokens-v3.6.1', true], ['tokens-android-v6.5.1', true], ['v5.1.2', true], ['components — unchanged', false], ['icons — unchanged', false], ['fonts — unchanged', false]]
    .forEach(([t, c]) => releaseRow.appendChild(relChip(t, c)));

  ws.add(nodeLayer); ws.add(hexChip); ws.add(diffChip); ws.add(checksChip); ws.add(traveler); ws.add(releaseRow);
  tag(ws, 'pipeline');
  const camT = staticCam();
  const clicks = [3.0, 8.85];

  const travT = track([
    [0, nodeX[0]], [2.95, nodeX[0], 'lin'],
    [3.0, nodeX[1], 'io5'], [5.55, nodeX[1], 'lin'],
    [5.65, nodeX[2], 'io5'], [8.75, nodeX[2], 'lin'],
    [8.85, nodeX[3], 'io5'], [10.5, nodeX[3], 'lin'],
    [10.6, nodeX[4], 'io5'], [16, nodeX[4], 'lin'],
  ]);

  return function render(t) {
    ws.cam(t, camT, clicks);
    rise(nodeLayer, t, 0.08, 0.6, 20);

    const active = t < 3.0 ? 0 : t < 5.6 ? 1 : t < 8.8 ? 2 : t < 10.6 ? 3 : 4;
    nodes.forEach((n, i) => S(n.circle, { background: i <= active ? '#0000FF' : '#fff', boxShadow: i <= active ? '0 0 0 1px #0000FF, 0 18px 40px rgba(0,0,255,.18)' : '0 0 0 1px rgba(0,0,0,.1)' }));
    nodes.forEach((n, i) => S(n.sub, { color: i <= active ? '#0000FF' : '#14161C' }));

    const tx = travT(t);
    S(traveler, { transform: `translateX(${(tx - 19).toFixed(1)}px)` });

    const typing = t >= 1.45;
    const txt = typing ? '#' + 'C8001E'.slice(0, Math.max(0, Math.round((t - 1.45) * 16))) : '#DD0000';
    if (hexChip_val.textContent !== txt) hexChip_val.textContent = txt;
    S(hexChip_sw, { background: t >= 2.05 ? '#C8001E' : '#DD0000' });

    show(hexChip, t < 3.0);
    show(diffChip, t >= 5.65 && t < 8.85);
    show(checksChip, t >= 8.85 && t < 10.6);
    if (t < 12.85) S(releaseRow, { opacity: '0', visibility: 'hidden' }); else rise(releaseRow, t, 12.85, 0.6, 20);

    ws.point(t, [
      { t: 0, p: [1400, 900], d: 0.01 },
      { t: 1.1, p: ws.a('node0', 0.5, 0.5), d: 1.0 },
      { t: 3.0, p: ws.a('node1', 0.5, 0.5), d: 1.2 },
      { t: 5.6, p: ws.a('node2', 0.5, 0.5), d: 1.2 },
      { t: 8.8, p: ws.a('node3', 0.5, 0.5), d: 1.2 },
      { t: 10.6, p: ws.a('node4', 0.5, 0.5), d: 1.0 },
      { t: 12.9, p: [1300, 760], d: 0.8 },
      { t: 16, p: [1330, 790], d: 2.5 },
    ], clicks);

    ws.caption(t, [
      [0.6, 2.95, '01', 'a designer changes one value in figma'],
      [3.05, 5.55, '02', 'the export opens a pull request by itself'],
      [5.65, 8.75, '03', 'the change arrives as a diff, never copied by hand'],
      [8.85, 12.75, '04', 'on merge, each release line hashes what it would publish'],
      [12.85, 16, '05', 'a refactor with identical output ships nothing'],
    ]);
  };
};

// ═════════════════════════════════════════════════════════════════════════════
// ACT 5 — guardrails · a hardcoded colour, caught and renamed
// ═════════════════════════════════════════════════════════════════════════════
A.acts.guardrails = function (ws) {
  const card = h('div', { style: 'position:absolute;left:360px;top:260px;width:1200px;height:560px;background:#14161C;border-radius:20px;box-shadow:0 0 0 1px rgba(0,0,0,.4),0 30px 70px rgba(10,10,14,.35);padding:70px 80px;box-sizing:border-box;color:#fff;font-family:var(--mono)' });
  const line_hex = h('span', { style: 'color:#B5CEA8;text-decoration:underline wavy #CCA700;text-underline-offset:8px' }, '#dd0000');
  const line_var = h('span', { style: 'color:#DCDCAA;display:none' }, 'var');
  const line_p1 = h('span', { style: 'color:#808080;display:none' }, '(');
  const line_tok = h('span', { style: 'color:#9CDCFE;display:none' }, '--bg-color-brand-solid');
  const line_p2 = h('span', { style: 'color:#808080;display:none' }, ')');
  const line = h('div', { style: 'font-size:34px;line-height:1.6' },
    h('span', { style: 'color:#9CDCFE' }, 'background'), h('span', { style: 'color:#808080' }, ': '),
    line_hex, line_var, line_p1, line_tok, line_p2,
    h('span', { style: 'color:#808080' }, ';'));
  const warn = h('div', { style: 'margin-top:28px;display:flex;align-items:center;gap:14px;font-size:20px;color:#CCCCCC' },
    h('span', { style: 'width:20px;height:20px;border-radius:50%;background:#CCA700;flex:none;display:flex;align-items:center;justify-content:center;color:#14161C;font-weight:800;font-size:14px' }, '!'),
    h('span', { text: 'Hardcoded colour — use a design token' }));

  const results = h('div', { style: 'margin-top:48px;display:flex;flex-direction:column;gap:14px;font-size:22px;color:#CCCCCC' });
  const resultLines = ['--bg-color-brand-solid', '--text-color-brand', '--text-color-brand-light-only'].map((t) => {
    const el = h('div', null, h('span', { style: 'color:#6A9955' }, 'token  '), h('span', { style: 'color:#9CDCFE' }, t));
    results.appendChild(el);
    return el;
  });

  const shipped = h('div', { style: 'margin-top:48px;display:inline-flex;align-items:center;gap:12px;background:rgba(0,255,0,.08);border-radius:10px;padding:12px 20px;font-size:19px;color:#9FE6A8' },
    h('span', { text: 'renames ship inside the package — for people and agents' }));

  card.append(line, warn, results, shipped);
  ws.add(card);
  tag(ws, 'guardrails');
  const camT = staticCam();
  const clicks = [6.65];

  return function render(t) {
    ws.cam(t, camT, clicks);
    rise(card, t, 0.08, 0.6, 20);

    show(warn, t < 3.35);
    show(results, t >= 3.35 && t < 6.65);
    resultLines.forEach((el, i) => rise(el, t, 3.5 + i * 0.3, 0.45, 12));

    const fixed = t >= 6.65;
    S(line_hex, { display: fixed ? 'none' : 'inline' });
    [line_var, line_p1, line_tok, line_p2].forEach((s) => S(s, { display: fixed ? 'inline' : 'none' }));
    show(shipped, fixed);
    if (fixed) rise(shipped, t, 6.8, 0.5, 12);

    ws.point(t, [
      { t: 0, p: [1500, 980], d: 0.01 },
      { t: 1.25, p: [1000, 390], d: 1.1 },
      { t: 3.45, p: [1000, 530], d: 1.0 },
      { t: 6.65, p: [1000, 390], d: 1.0 },
      { t: 8.0, p: [1000, 720], d: 1.0 },
      { t: 10, p: [1010, 740], d: 2.0 },
    ], clicks);

    ws.caption(t, [
      [0.8, 3.35, '01', 'the linter flags a hardcoded colour'],
      [3.45, 6.55, '02', 'the cli names the tokens that hold it'],
      [6.65, 10, '03', 'renames ship inside the package, for people and agents'],
    ]);
  };
};
